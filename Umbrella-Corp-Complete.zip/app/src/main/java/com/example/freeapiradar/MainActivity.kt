package com.example.freeapiradar

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var layoutMenu1: View
    private lateinit var layoutMenu2: View
    private var isAdultAccessGranted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        layoutMenu1 = findViewById(R.id.menu_page_1)
        layoutMenu2 = findViewById(R.id.menu_page_2)
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottom_navigation)

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_system -> {
                    layoutMenu1.visibility = View.VISIBLE
                    layoutMenu2.visibility = View.GONE
                    true
                }
                R.id.nav_catalog -> {
                    layoutMenu1.visibility = View.GONE
                    layoutMenu2.visibility = View.VISIBLE
                    true
                }
                else -> false
            }
        }

        setupFeedbackOption()
        setupCatalogCategories()
    }

    private fun setupFeedbackOption() {
        val btnFeedback = findViewById<Button>(R.id.btn_umbrella_feedback)
        btnFeedback.setOnClickListener {
            val input = EditText(this).apply {
                hint = "Enter incident or data report..."
                setTextColor(resources.getColor(android.R.color.white, null))
            }
            AlertDialog.Builder(this)
                .setTitle("TRANSMIT INCIDENT LOG // UMBRELLA HQ")
                .setMessage("Submit telemetry or feedback to Umbrella central servers:")
                .setView(input)
                .setPositiveButton("TRANSMIT") { _, _ ->
                    val text = input.text.toString()
                    if (text.isNotBlank()) {
                        Toast.makeText(this, "[ENCRYPTED TRANSMISSION DISPATCHED]", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("ABORT", null)
                .show()
        }
    }

    private fun setupCatalogCategories() {
        val spinner = findViewById<Spinner>(R.id.category_spinner)
        val categories = arrayOf(
            "ALL FEEDS",
            "Text to Speech (TTS)",
            "3D Modelling & Mesh (.glb/.obj)",
            "AI / LLM Inferences",
            "RESTRICTED 18+ (ADULT ARCHIVE)"
        )

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        spinner.adapter = adapter

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selected = categories[position]
                if (selected.contains("18+")) {
                    verifyAdultClearance(spinner)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun verifyAdultClearance(spinner: Spinner) {
        if (isAdultAccessGranted) return

        AlertDialog.Builder(this)
            .setTitle("BIOHAZARD CLEARANCE PROTOCOL: 18+")
            .setMessage("RESTRICTED DIRECTORY!\n\nUmbrella Corporation policy mandates confirmation of 18+ legal age. Do you declare legal majority status to access adult endpoints?")
            .setCancelable(false)
            .setPositiveButton("I AM 18+ / AUTHORIZE") { _, _ ->
                isAdultAccessGranted = true
                Toast.makeText(this, "CLEARANCE GRANTED // 18+ ADULT CATALOG UNLOCKED", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("DENY ACCESS") { _, _ ->
                isAdultAccessGranted = false
                spinner.setSelection(0)
                Toast.makeText(this, "ACCESS DENIED: CLEARANCE INSUFFICIENT", Toast.LENGTH_SHORT).show()
            }
            .show()
    }
}