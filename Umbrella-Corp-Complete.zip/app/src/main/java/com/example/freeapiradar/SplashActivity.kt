package com.example.freeapiradar

import android.annotation.SuppressLint
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.ScaleAnimation
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    private var mediaPlayer: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val bootMessage = "WITH OUR CORPORATION YOU CAN FEEL SAFE AND SECURE. YOUR LIFE IS OUR BUSINESS..."
    private var charIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val splashLogo = findViewById<ImageView>(R.id.splash_logo)
        val typewriterText = findViewById<TextView>(R.id.splash_terminal_text)
        val subtitle = findViewById<TextView>(R.id.splash_subtitle)

        try {
            mediaPlayer = MediaPlayer.create(this, R.raw.umbrella_intro).apply { start() }
        } catch (e: Exception) {}

        val scaleAnim = ScaleAnimation(0.92f, 1.05f, 0.92f, 1.05f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f).apply {
            duration = 1400
            repeatMode = Animation.REVERSE
            repeatCount = Animation.INFINITE
        }
        splashLogo.startAnimation(scaleAnim)

        val glitchAnim = AlphaAnimation(0.3f, 1.0f).apply {
            duration = 180
            repeatMode = Animation.REVERSE
            repeatCount = Animation.INFINITE
        }
        subtitle.startAnimation(glitchAnim)

        handler.post(object : Runnable {
            override fun run() {
                if (charIndex <= bootMessage.length) {
                    typewriterText.text = bootMessage.substring(0, charIndex)
                    charIndex++
                    handler.postDelayed(this, 40)
                }
            }
        })

        handler.postDelayed({
            mediaPlayer?.stop()
            mediaPlayer?.release()
            startActivity(Intent(this@SplashActivity, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 4200)
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        handler.removeCallbacksAndMessages(null)
    }
}