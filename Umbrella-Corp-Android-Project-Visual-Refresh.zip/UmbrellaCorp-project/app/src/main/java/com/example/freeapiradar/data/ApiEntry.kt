package com.example.freeapiradar.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "apis")
data class ApiEntry(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val category: String,
    val auth: String,
    val https: String,
    val docsUrl: String,
    val source: String,
    val firstSeen: Long,
    val lastSeen: Long,
    val siteStatus: String = "Not checked",
    val statusCheckedAt: Long = 0L
) {
    val needsKey: Boolean get() = auth.isNotBlank() && !auth.equals("No", true) && !auth.equals("None", true)
}
