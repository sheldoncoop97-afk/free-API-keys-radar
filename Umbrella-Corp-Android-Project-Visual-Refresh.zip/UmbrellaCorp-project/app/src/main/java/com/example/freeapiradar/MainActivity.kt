package com.example.freeapiradar

import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.work.*
import com.example.freeapiradar.data.ApiEntry
import com.example.freeapiradar.data.ApiRepository
import com.example.freeapiradar.worker.ScanWorker
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

private val UmbrellaRed = Color(0xFFE50922)
private val UmbrellaBlack = Color(0xFF08090C)
private val UmbrellaPanel = Color(0xFF15171C)
private val UmbrellaWhite = Color(0xFFF4F4F4)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private var tts: TextToSpeech? = null
    private var introPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        schedulePeriodicScan()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.US
        }
        setContent {
            val darkColors = darkColorScheme(primary = UmbrellaRed, onPrimary = Color.White, background = UmbrellaBlack, onBackground = UmbrellaWhite, surface = UmbrellaPanel, onSurface = UmbrellaWhite, secondary = Color(0xFFFF3349), outline = Color(0xFF454852))
            MaterialTheme(colorScheme = darkColors) {
                Surface(Modifier.fillMaxSize(), color = UmbrellaBlack) {
                    var showSplash by remember { mutableStateOf(true) }
                    LaunchedEffect(Unit) {
                        try { introPlayer = MediaPlayer.create(this@MainActivity, R.raw.umbrella_intro); introPlayer?.start() } catch (_: Exception) { }
                        delay(6200)
                        showSplash = false
                        introPlayer?.let { player -> if (player.isPlaying) player.pause(); player.seekTo(0) }
                    }
                    Box(Modifier.fillMaxSize()) {
                        RadarScreen(ApiRepository(applicationContext), ::runScan, ::openWebsite)
                        AnimatedVisibility(visible = showSplash, enter = fadeIn(tween(300)), exit = fadeOut(tween(650))) {
                            UmbrellaSplash()
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        introPlayer?.run { if (isPlaying) stop(); release() }
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }

    private fun openWebsite(url: String) {
        try {
            val uri = Uri.parse(url.trim())
            if (uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) {
                Toast.makeText(this, "Nieprawidłowy adres strony", Toast.LENGTH_SHORT).show()
                return
            }

            // Prefer Chrome, but don't rely on resolveActivity() package visibility checks.
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage("com.android.chrome")
                })
                return
            } catch (_: Exception) {
                // Chrome is not installed/enabled; try the default browser instead.
            }

            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            } catch (_: Exception) {
                Toast.makeText(
                    this,
                    "Zainstaluj lub włącz Chrome albo inną przeglądarkę",
                    Toast.LENGTH_LONG
                ).show()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Nie udało się otworzyć strony", Toast.LENGTH_LONG).show()
        }
    }

    private fun schedulePeriodicScan() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        // Android WorkManager minimum periodic interval is 15 minutes; actual execution can be delayed by Doze/battery policy.
        val periodic = PeriodicWorkRequestBuilder<ScanWorker>(15, TimeUnit.MINUTES).setConstraints(constraints).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("free-api-radar-periodic", ExistingPeriodicWorkPolicy.KEEP, periodic)
        WorkManager.getInstance(this).enqueue(OneTimeWorkRequestBuilder<ScanWorker>().setConstraints(constraints).build())
    }

    private fun runScan() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        WorkManager.getInstance(this).enqueue(OneTimeWorkRequestBuilder<ScanWorker>().setConstraints(constraints).build())
    }
}

@Composable
private fun UmbrellaSplash() {
    var reveal by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(120); reveal = true }
    val alpha by animateFloatAsState(if (reveal) 1f else 0f, tween(850), label = "splashAlpha")
    Box(Modifier.fillMaxSize().background(UmbrellaBlack), contentAlignment = Alignment.Center) {
        Image(
            painter = painterResource(R.drawable.umbrella_splash),
            contentDescription = "Umbrella Corporation boot screen",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxWidth().aspectRatio(1536f / 1365f).alpha(alpha)
        )
        Text(
            "SECURE CONNECTION // INITIALIZING",
            color = Color(0xFF00BCEB),
            fontSize = 9.sp,
            letterSpacing = 2.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp).alpha(alpha)
        )
    }
}

@Composable
private fun RadarScreen(repo: ApiRepository, onScan: () -> Unit, openWebsite: (String) -> Unit) {
    val apis by repo.observe().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var keyFilter by remember { mutableStateOf("All") }
    var scanning by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Umbrella network initialized. New sources are checked periodically.") }
    var showSources by remember { mutableStateOf(false) }
    var sourceInput by remember { mutableStateOf("") }
    var customSources by remember { mutableStateOf(repo.customSources()) }
    val categories = listOf("All", "AI & LLM", "Image & Video", "Audio & Speech", "Automation & Agents", "Developer Tools", "Other")
    val visible = apis.filter { entry ->
        (selectedCategory == "All" || entry.category == selectedCategory) &&
        (keyFilter == "All" || (keyFilter == "No key" && !entry.needsKey) || (keyFilter == "Key needed" && entry.needsKey)) &&
        (query.isBlank() || "${entry.name} ${entry.description} ${entry.category}".contains(query, true))
    }
    Column(Modifier.fillMaxSize().background(UmbrellaBlack).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Image(painterResource(R.drawable.umbrella_icon), contentDescription = "Umbrella", modifier = Modifier.size(48.dp))
            Column(Modifier.weight(1f)) {
                Text("UMBRELLA CORP", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, color = UmbrellaWhite)
                Text("FREE API RADAR  //  UMBRELLA CORPORATION", style = MaterialTheme.typography.labelSmall, color = UmbrellaRed, letterSpacing = 1.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { scanning = true; message = "Scan queued. Results will appear after the background task finishes."; onScan(); scanning = false }, colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed)) { Text("SCAN NOW") }
            OutlinedButton(onClick = { customSources = repo.customSources(); showSources = true }) { Text("MY SOURCES (${customSources.size})") }
            Text("${apis.size} APIs", style = MaterialTheme.typography.titleMedium)
        }
        Text("AUTO-SCAN: every 15 min (Android may delay) · PUBLIC CATALOGS + FREE-KEY PROVIDERS", style = MaterialTheme.typography.labelSmall, color = UmbrellaRed)
        Text(message, style = MaterialTheme.typography.bodySmall, color = Color(0xFFB4B8C2))
        Spacer(Modifier.height(8.dp))
        BasicTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().background(UmbrellaPanel).padding(12.dp), textStyle = MaterialTheme.typography.bodyMedium.copy(color = UmbrellaWhite), decorationBox = { inner ->
            if (query.isEmpty()) Text("Search API catalog…", color = Color(0xFF8B909A))
            inner()
        })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "No key", "Key needed").forEach { option -> FilterChip(selected = keyFilter == option, onClick = { keyFilter = option }, label = { Text(option) }) }
        }
        if (showSources) {
            AlertDialog(
                onDismissRequest = { showSources = false },
                title = { Text("UMBRA // OBSERVED SOURCES") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Wbudowane źródła obejmują katalogi publicznych API, katalogi darmowych API AI/LLM oraz listę dostawców z rejestracją i możliwym darmowym limitem. Dodaj publiczny plik Markdown z tabelą lub listą linków HTTPS. Nie każdy układ strony da się automatycznie sparsować.", style = MaterialTheme.typography.bodySmall)
                        Text("Publiczne/demo access jest tylko kandydatem do sprawdzenia. Nie zbieramy wyciekłych kluczy. Darmowe limity, kraje i modele mogą się zmieniać.", style = MaterialTheme.typography.bodySmall, color = UmbrellaRed)
                        OutlinedTextField(value = sourceInput, onValueChange = { sourceInput = it }, label = { Text("Adres źródła HTTPS") }, singleLine = true)
                        Button(onClick = {
                            if (repo.addCustomSource(sourceInput)) {
                                sourceInput = ""; customSources = repo.customSources(); message = "Źródło dodane. Uruchamiam skanowanie."; onScan()
                            } else message = "Nieprawidłowy adres. Wklej pełny adres HTTPS."
                        }) { Text("ADD SOURCE") }
                        if (customSources.isNotEmpty()) Text("ZAPISANE ŹRÓDŁA", color = UmbrellaRed, fontWeight = FontWeight.Bold)
                        customSources.forEach { source ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(source, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                TextButton(onClick = { repo.removeCustomSource(source); customSources = repo.customSources() }) { Text("REMOVE") }
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showSources = false }) { Text("DONE") } }
            )
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text("UMBRELLA CATALOG // CATEGORIES", fontWeight = FontWeight.SemiBold, color = UmbrellaRed, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    categories.chunked(2).forEach { pair -> Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { pair.forEach { cat -> FilterChip(selected = selectedCategory == cat, onClick = { selectedCategory = cat }, label = { Text(cat) }) } } }
                }
                Divider(Modifier.padding(vertical = 8.dp), color = Color(0xFF393B43))
            }
            if (visible.isEmpty()) item { Text("No entries yet. Tap SCAN NETWORK and check your connection.", modifier = Modifier.padding(16.dp)) }
            items(visible, key = { it.id }) { entry -> ApiCard(entry = entry, onCheck = {
                scope.launch {
                    message = "Checking ${entry.name} website…"
                    val status = repo.checkWebsite(entry)
                    repo.saveStatus(entry.id, status)
                    message = "${entry.name}: $status. API access/pricing may differ."
                }
            }, onOpenWebsite = { openWebsite(entry.docsUrl) }) }
        }
    }
}

@Composable
private fun ApiCard(entry: ApiEntry, onCheck: () -> Unit, onOpenWebsite: () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = UmbrellaPanel)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(entry.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = UmbrellaWhite)
            Text(entry.description, style = MaterialTheme.typography.bodyMedium)
            Text("${entry.category} · Access: ${entry.auth} · HTTPS: ${entry.https}", style = MaterialTheme.typography.bodySmall)
            Text("Docs: ${entry.docsUrl}", style = MaterialTheme.typography.bodySmall)
            Text("Source: ${entry.source} · last catalog scan: ${DateFormat.getDateTimeInstance().format(Date(entry.lastSeen))}", style = MaterialTheme.typography.labelSmall)
            Text("Website status: ${entry.siteStatus}${if (entry.statusCheckedAt > 0) " · ${DateFormat.getDateTimeInstance().format(Date(entry.statusCheckedAt))}" else ""}", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onOpenWebsite, colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed)) { Text("OPEN WEBSITE") }
                OutlinedButton(onClick = onCheck) { Text("CHECK STATUS") }
            }
        }
    }
}
