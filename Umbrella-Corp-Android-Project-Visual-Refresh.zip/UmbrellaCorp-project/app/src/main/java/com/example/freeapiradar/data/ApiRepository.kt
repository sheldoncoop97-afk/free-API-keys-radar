package com.example.freeapiradar.data

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URI
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class ApiRepository(context: Context) {
    private val dao = ApiDatabase.get(context).apiDao()
    private val client = OkHttpClient.Builder()
        .callTimeout(20, TimeUnit.SECONDS)
        .connectTimeout(10, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    fun observe() = dao.observeAll()
    suspend fun count() = dao.count()

    private val prefs = context.getSharedPreferences("custom_sources", Context.MODE_PRIVATE)
    fun customSources(): List<String> = prefs.getStringSet("urls", emptySet())?.toList()?.sorted().orEmpty()
    fun addCustomSource(raw: String): Boolean {
        val url = raw.trim()
        val uri = try { URI(url) } catch (_: Exception) { return false }
        if (uri.scheme != "https" || uri.host.isNullOrBlank()) return false
        val updated = customSources().toMutableSet()
        updated.add(url)
        prefs.edit().putStringSet("urls", updated).apply()
        return true
    }
    fun removeCustomSource(url: String) {
        val updated = customSources().toMutableSet()
        updated.remove(url)
        prefs.edit().putStringSet("urls", updated).apply()
    }

    // Public catalog files only. No secret scanning, credential extraction, or collection of exposed keys.
    // Public catalogs: Markdown sources are parsed for documented API entries. Some projects
    // change their layout; a failed parser/source must never prevent the other sources scanning.
    private val catalogs = listOf(
        "https://raw.githubusercontent.com/public-apis/public-apis/master/README.md",
        "https://raw.githubusercontent.com/public-api-lists/public-api-lists/main/README.md",
        "https://raw.githubusercontent.com/free-public-apis/apis/main/README.md",
        "https://raw.githubusercontent.com/IdoY12/awesome-free-ai-apis/main/README.md",
        "https://raw.githubusercontent.com/pacocartones/free-llm-api-hub/main/README.md"
    )

    // Curated provider sign-up pages. These are leads, not a promise of unlimited or permanent free use.
    private val curatedDirectories = listOf(
        Triple("API Atlas directory", "Public API discovery directory; directory page is a lead, not a parsed live feed", "https://www.atlasapi.space/"),
        Triple("Awesome Free AI APIs", "Community-maintained directory of free AI API options", "https://github.com/IdoY12/awesome-free-ai-apis"),
        Triple("Free LLM API Hub", "Community directory of free LLM API options and limits", "https://github.com/pacocartones/free-llm-api-hub")
    )

    private val curatedProviders = listOf(
        Triple("Google AI Studio", "Gemini API; free quota may be available depending on model, region and current terms", "https://aistudio.google.com/"),
        Triple("GroqCloud", "Fast inference API; free developer tier/limits may apply", "https://console.groq.com/"),
        Triple("OpenRouter", "Model gateway; selected models may have free access and changing limits", "https://openrouter.ai/"),
        Triple("Hugging Face Inference", "Hosted models; free usage may be limited by current plan", "https://huggingface.co/"),
        Triple("Cohere", "Developer API; trial/free limits depend on current terms", "https://dashboard.cohere.com/"),
        Triple("Cloudflare Workers AI", "AI inference with account-based usage limits/allowance", "https://developers.cloudflare.com/workers-ai/"),
        Triple("GitHub Models", "Model testing/API access subject to account eligibility and rate limits", "https://github.com/marketplace/models"),
        Triple("Mistral AI La Plateforme", "Developer API; any free allowance depends on current account terms", "https://console.mistral.ai/")
    )

    suspend fun scan(): Int {
        val now = System.currentTimeMillis()
        val found = mutableMapOf<String, ApiEntry>()
        val allSources = catalogs + customSources()
        allSources.forEachIndexed { sourceIndex, url ->
            try {
                val req = Request.Builder().url(url).header("User-Agent", "FreeApiRadar-Android/1.0").build()
                client.newCall(req).execute().use { response ->
                    if (!response.isSuccessful) return@forEachIndexed
                    val body = response.body?.string().orEmpty()
                    val source = URI(url).host ?: "public catalog"
                    var category = "Other"
                    body.lineSequence().forEach { line ->
                        val heading = Regex("^#{1,4}\\s+(.+?)\\s*#*\\s*$").find(line)?.groupValues?.get(1)
                        if (heading != null) category = classify(heading)
                        if (!line.trim().startsWith("|") || line.count { it == '|' } < 4 || line.contains("---")) return@forEach
                        val cells = line.trim().trim('|').split('|').map { it.trim().trim('`') }
                        if (cells.size < 3) return@forEach
                        val name = cells[0].removeMarkdown().trim()
                        val desc = cells.getOrNull(1)?.removeMarkdown()?.trim().orEmpty()
                        if (name.isBlank() || name.equals("API", true) || name.length > 100 || desc.isBlank()) return@forEach
                        val link = Regex("https?://[^ )>]+")
                        val docs = link.find(cells[0])?.value ?: link.find(line)?.value ?: return@forEach
                        if (!docs.startsWith("https://")) return@forEach
                        val auth = cells.getOrNull(2)?.removeMarkdown()?.trim().orEmpty().ifBlank { "Unknown" }
                        val https = cells.getOrNull(3)?.removeMarkdown()?.trim().orEmpty().ifBlank { "Unknown" }
                        if (name.length < 2 || docs.contains("github.com/public-apis/public-apis/blob")) return@forEach
                        val id = sha256((name.lowercase() + "|" + docs.lowercase()))
                        val old = found[id]
                        found[id] = ApiEntry(
                            id = id, name = name, description = desc.take(500), category = if (category == "Other") classify("$name $desc") else category,
                            auth = auth, https = https, docsUrl = docs, source = source,
                            firstSeen = old?.firstSeen ?: now, lastSeen = now
                        )
                    }
                    // Also recognize linked Markdown list entries, common in Awesome-style catalogs.
                    body.lineSequence().forEach { line ->
                        if (!line.trimStart().startsWith("-") && !line.trimStart().startsWith("*")) return@forEach
                        val match = Regex("(?:[-*]\\s+)(?:\\[([^]]{2,100})]\\((https://[^ )]+)\\)|([^:]{2,100}):\\s*(https://[^ )]+))").find(line) ?: return@forEach
                        val name = (match.groupValues[1].ifBlank { match.groupValues[3] }).trim().trim('`', '*')
                        val docs = (match.groupValues[2].ifBlank { match.groupValues[4] }).trim().trimEnd('.', ',', ')')
                        if (name.isBlank() || docs.isBlank() || name.equals("license", true)) return@forEach
                        val id = sha256((name.lowercase() + "|" + docs.lowercase()))
                        found[id] = ApiEntry(id, name, line.removeMarkdown().take(500), classify("$name $line $url"), "Unknown — verify provider terms", "HTTPS", docs, source, found[id]?.firstSeen ?: now, now)
                    }
                }
            } catch (_: Exception) { /* Keep scanning other sources if one is unavailable. */ }
        }
        curatedDirectories.forEach { (name, description, docs) ->
            val id = sha256((name.lowercase() + "|" + docs.lowercase()))
            found[id] = ApiEntry(id, name, description, "Developer Tools", "Catalog directory — follow link to inspect entries", "HTTPS", docs, "Umbra curated directory list", found[id]?.firstSeen ?: now, now)
        }
        curatedProviders.forEach { (name, description, docs) ->
            val id = sha256((name.lowercase() + "|" + docs.lowercase()))
            found[id] = ApiEntry(id, name, description, "AI & LLM", "Free account/key may be required; verify current terms", "HTTPS", docs, "Umbra curated provider directory", found[id]?.firstSeen ?: now, now)
        }
        // Public/demo endpoints are marked as candidates only; never harvest leaked credentials.
        val genuinelyNew = found.values.filter { dao.get(it.id) == null }
        if (found.isNotEmpty()) dao.upsertAll(found.values.toList())
        return genuinelyNew.size
    }

    suspend fun checkWebsite(entry: ApiEntry): String {
        return try {
            val request = Request.Builder().url(entry.docsUrl).header("User-Agent", "FreeApiRadar-Android/1.0").head().build()
            client.newCall(request).execute().use { response ->
                when {
                    response.code in 200..399 -> "Website responds (${response.code})"
                    response.code == 405 || response.code == 403 -> "Website reachable (${response.code})"
                    else -> "HTTP ${response.code}"
                }
            }
        } catch (e: Exception) { "Connection failed" }
    }

    suspend fun saveStatus(id: String, status: String) = dao.updateStatus(id, status, System.currentTimeMillis())

    private fun classify(text: String): String {
        val s = text.lowercase()
        return when {
            listOf("google ai studio", "groqcloud", "openrouter", "hugging face inference", "cohere", "cloudflare workers ai", "github models", "mistral ai").any(s::contains) -> "AI & LLM"
            listOf("llm", "language model", "generative ai", "artificial intelligence", "machine learning", "ai ", "ai/", "inference", "embedding").any(s::contains) -> "AI & LLM"
            listOf("image", "text-to-image", "video", "animation", "diffusion").any(s::contains) -> "Image & Video"
            listOf("audio", "speech", "voice", "music", "transcription", "text-to-speech").any(s::contains) -> "Audio & Speech"
            listOf("automation", "workflow", "agent", "integration", "no-code").any(s::contains) -> "Automation & Agents"
            listOf("developer", "code", "programming", "github", "repository", "package").any(s::contains) -> "Developer Tools"
            else -> "Other"
        }
    }
    private fun String.removeMarkdown() = replace(Regex("\\[([^]]+)]\\([^)]*\\)"), "\u00241").replace("**", "").replace("*", "").replace("`", "").trim()
    private fun sha256(value: String) = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}
