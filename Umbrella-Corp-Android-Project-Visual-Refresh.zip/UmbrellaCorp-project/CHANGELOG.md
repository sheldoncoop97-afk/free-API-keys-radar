# Changelog — Umbrella Corp

## Umbra Watch 1.3 — packaged project
- Consolidated the Android source into a standalone Android Studio project.
- Set the launcher/app label to **Umbrella Corp**.
- Updated the main in-app heading to **UMBRELLA CORP**.
- Fixed the website button callback so catalog entries pass their documentation URL to the activity.
- Updated link opening to try Chrome first and then the default/available browser.
- Added a standalone GitHub Actions workflow that builds and uploads `Umbrella-Corp-debug-apk`.
- Preserved the existing Umbrella logo, startup animation/audio, catalog scanning, MY SOURCES, notifications and 15-minute WorkManager configuration.
