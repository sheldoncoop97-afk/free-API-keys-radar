# Free API Radar - Umbrella Corporation

Kompletny projekt gotowy do kompilacji pliku APK na GitHub Actions.

## 🚀 Jak skompilować APK na GitHub Actions:
1. Wypakuj ten plik ZIP lub stwórz nowe repozytorium na GitHubie.
2. Wrzuć pliki do repozytorium (np. git init, git add ., git commit -m "init", git push).
3. Wejdź na stronę swojego repozytorium na GitHubie i kliknij zakładkę **Actions**.
4. Wybierz workflow: **Build Android APK - Free API Radar Umbrella**.
5. Kliknij **Run workflow** -> **Run workflow**.
6. Po około 2-3 minutach proces się zakończy sukcesem i w sekcji **Artifacts** na dole strony pojawi się gotowy plik **FreeAPIRadar-Umbrella-APK** do pobrania i instalacji na telefonie!

## 📱 Zawartość paczki:
-  - pełna automatyzacja budowania APK (JDK 17 + Node 20 + Android SDK)
-  - komplet grafik: logo.png (1024x1024), splash_bg.png (1080x1920), ikony (512, 192, 72, 48, 36, 24 px)
-  - cała działająca aplikacja z drugą przestrzenią 18+, wyszukiwarką, generatorem wideo Veo 3.1 i dźwiękami Umbrella
