import React from 'react';
import { playUiBeep } from '../audio/umbrellaSound';
import { Home, Star, Clock, Settings, ShieldAlert, Film } from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
  favoritesCount: number;
  historyCount: number;
  isAdultSpace: boolean;
  onToggleAdultSpace: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onSelectTab,
  favoritesCount,
  historyCount,
  isAdultSpace,
  onToggleAdultSpace
}) => {
  const tabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'favorites', label: 'Favorites', icon: Star, badge: favoritesCount },
    { id: 'history', label: 'History', icon: Clock, badge: historyCount },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#08090c]/95 backdrop-blur-lg border-t border-red-950/80 font-['Rajdhani'] safe-area-pb">
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-around">
        {tabs.map((tab) => {
          const IconComp = tab.icon;
          const isSelected = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                playUiBeep(1000, 0.03);
                onSelectTab(tab.id);
              }}
              className={`relative flex flex-col items-center justify-center py-1 px-3 transition-all ${
                isSelected
                  ? 'text-red-500 scale-105'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <div className="relative">
                <IconComp size={20} className={isSelected ? 'stroke-[2.5]' : 'stroke-2'} />
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="absolute -top-1 -right-2 px-1 rounded-full text-[9px] font-mono bg-red-600 text-white font-bold leading-tight">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className={`text-[11px] font-mono tracking-wider mt-0.5 ${isSelected ? 'font-bold text-white' : ''}`}>
                {tab.label}
              </span>
              {isSelected && (
                <span className="w-1 h-1 rounded-full bg-red-500 mt-0.5 shadow-[0_0_6px_#ef4444]" />
              )}
            </button>
          );
        })}

        {/* Mobile quick space toggle indicator */}
        <button
          onClick={() => {
            playUiBeep(1200, 0.04);
            onToggleAdultSpace();
          }}
          className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-lg text-xs font-mono transition-all ${
            isAdultSpace
              ? 'text-red-400 border border-red-600/40 bg-red-950/40'
              : 'text-zinc-500 hover:text-zinc-300'
          }`}
          title="Przełącz Druga Przestrzeń (18+)"
        >
          <ShieldAlert size={18} className={isAdultSpace ? "text-red-500 animate-pulse" : ""} />
          <span className="text-[10px] mt-0.5">{isAdultSpace ? '18+' : 'Radar'}</span>
        </button>
      </div>
    </nav>
  );
};
