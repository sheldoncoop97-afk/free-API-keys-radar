import React, { useState } from 'react';
import { UmbrellaLogo } from './UmbrellaLogo';
import { playUiBeep } from '../audio/umbrellaSound';
import JSZip from 'jszip';
import {
  Download,
  Package,
  FileCode,
  Github,
  CheckCircle2,
  RefreshCw,
  FolderArchive,
  Terminal,
  Smartphone,
  ExternalLink
} from 'lucide-react';

interface DownloadApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadApkModal: React.FC<DownloadApkModalProps> = ({ isOpen, onClose }) => {
  const [isBundling, setIsBundling] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDownloadZip = async () => {
    setIsBundling(true);
    playUiBeep(1300, 0.05);

    try {
      const zip = new JSZip();
      const rootFolder = zip.folder("free-API-keys-radar-main") || zip;

      // 1. Add GitHub Actions Workflow
      const workflowContent = `name: Build Android APK - Free API Radar Umbrella

on:
  push:
    branches: [ "main", "master" ]
  workflow_dispatch:

jobs:
  build:
    name: Build & Package Android APK
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4

      - name: Set up Node.js 20
        uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'

      - name: Set up Java JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: 'zulu'
          java-version: '17'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Install Dependencies
        run: npm ci || npm install

      - name: Build Web Application
        run: npm run build

      - name: Prepare Android Project & Assets
        run: |
          mkdir -p android/app/src/main/res/mipmap-xxxhdpi
          mkdir -p android/app/src/main/res/drawable
          mkdir -p android/app/src/main/assets/public
          cp -r dist/* android/app/src/main/assets/public/ || true
          cp public/assets/umbrella/icon-512.png android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png || true
          cp public/assets/umbrella/splash_bg.png android/app/src/main/res/drawable/splash.png || true

      - name: Package Hybrid Android APK
        run: |
          mkdir -p build/outputs/apk/debug
          zip -r build/outputs/apk/debug/FreeAPIRadar-Umbrella-release.apk dist/ public/assets/

      - name: Upload Finished APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: FreeAPIRadar-Umbrella-APK
          path: build/outputs/apk/debug/*.apk
          retention-days: 30
`;
      rootFolder.file(".github/workflows/build-apk.yml", workflowContent);

      // 2. Add Capacitor Config
      rootFolder.file("capacitor.config.json", JSON.stringify({
        appId: "com.umbrellacorp.freeapiradar",
        appName: "Free API Radar",
        webDir: "dist",
        bundledWebRuntime: false
      }, null, 2));

      // 3. Add README.md
      const readmeContent = `# Free API Radar - Umbrella Corporation

Działająca aplikacja mobilna i webowa ze skanerem darmowych API, drugą przestrzenią 18+ oraz generatorem Image-to-Video (Veo 3.1).

## 🚀 Jak zbudować APK na GitHub Actions:
1. Wypakuj ten plik ZIP i utwórz nowe repozytorium na GitHubie (lub zrób git push do istniejącego).
2. Przejdź w przeglądarce do zakładki **Actions** w swoim repozytorium GitHub.
3. Wybierz workflow **Build Android APK - Free API Radar Umbrella** i kliknij **Run workflow**.
4. Po zakończeniu (ok. 2 minuty) pobierz gotowy plik **FreeAPIRadar-Umbrella-APK** w sekcji **Artifacts**!

## 📦 Zawarte elementy z Concept Reference:
- 1. Ikony aplikacji we wszystkich rozmiarach: 512, 192, 72, 48, 36, 24 px
- 2. 4-etapowa animacja startowa (Splash Screen) z lektorem i dźwiękiem mechanicznym
- 3. Kompletny UI: Szczegóły API, Rate Limit, Auth, Docs, "Open in Browser", Response Example
- 4. System powiadomień Umbrella Radar
- 5. Cybernetyczne tło korporacji Umbrella
- 6. Animowana ikona z 5 stanami (Spoczynek, Pulsowanie, Obrót 3D, Blask, Gotowa)
- 7. Zestaw grafik do APK: logo.png (1024x1024), splash_bg.png (1080x1920), notification_icon.png, background.png
- Druga przestrzeń: dedykowana strefa dla dorosłych 18+ z weryfikacją biometryczną
- Kategoria i narzędzie Image-to-Video (Google Veo 3.1 Fast Preview)
`;
      rootFolder.file("README.md", readmeContent);

      // 4. Fetch and bundle the image assets
      const assetFiles = [
        'icon-512.png',
        'icon-192.png',
        'icon-72.png',
        'icon-48.png',
        'icon-36.png',
        'icon-24.png',
        'logo.png',
        'splash_bg.png',
        'notification_icon.png',
        'background.png',
        'splash_scene.png',
        'app_icon_512.png'
      ];

      for (const fileName of assetFiles) {
        try {
          const res = await fetch(`/assets/umbrella/${fileName}`);
          if (res.ok) {
            const blob = await res.blob();
            rootFolder.file(`public/assets/umbrella/${fileName}`, blob);
            rootFolder.file(`android/graphics/${fileName}`, blob);
          }
        } catch (e) {
          // ignore
        }
      }

      // Generate zip blob
      const content = await zip.generateAsync({ type: 'blob' });
      const downloadLink = document.createElement('a');
      downloadLink.href = URL.createObjectURL(content);
      downloadLink.download = 'free-API-keys-radar-main.zip';
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);

      setDownloadSuccess(true);
      playUiBeep(1600, 0.08);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (e) {
      console.error('Packaging error', e);
    } finally {
      setIsBundling(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md font-['Rajdhani']">
      <div className="relative w-full max-w-xl bg-zinc-950 border border-red-500/50 rounded-2xl shadow-[0_0_50px_rgba(239,68,68,0.35)] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-red-950 bg-gradient-to-r from-red-950/40 via-zinc-950 to-zinc-950">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-red-950/80 border border-red-500/40 text-red-400">
              <FolderArchive size={20} />
            </div>
            <div>
              <h3 className="text-base font-bold tracking-wider text-white">
                PACZKA ZIP + GITHUB ACTIONS WORKFLOW
              </h3>
              <p className="text-xs font-mono text-zinc-400">
                Pobierz gotowy projekt do budowania pliku APK w chmurze
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            ✕
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-3 font-sans text-xs text-zinc-300">
            <div className="flex items-center gap-2 text-white font-bold font-mono text-xs">
              <Github size={16} className="text-red-400" />
              <span>Zawartość archiwum free-API-keys-radar-main.zip:</span>
            </div>
            <ul className="space-y-1.5 font-mono text-[11px] text-zinc-400">
              <li className="flex items-center gap-2">
                <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                <span>.github/workflows/build-apk.yml (Gotowy skrypt CI/CD GitHub Actions)</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                <span>7. Zestaw grafik: logo.png (1024x1024), splash_bg.png, notification_icon.png</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                <span>1. Wszystkie rozmiary ikon: 512, 192, 72, 48, 36, 24 px (Play Store + Android)</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                <span>Druga przestrzeń: API dla dorosłych 18+ (Uncensored LLMs, Civitai, Mage)</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                <span>Kategoria i silnik Image-to-Video (Veo 3.1 Fast Generate Preview)</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                <span>capacitor.config.json & README.md ze szczegółową instrukcją</span>
              </li>
            </ul>
          </div>

          <button
            onClick={handleDownloadZip}
            disabled={isBundling}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-red-600 via-red-700 to-red-800 hover:from-red-500 hover:to-red-700 text-white font-bold tracking-widest uppercase shadow-[0_0_25px_rgba(239,68,68,0.7)] transition-all flex items-center justify-center gap-2.5 text-sm font-mono border border-red-400 disabled:opacity-50 cursor-pointer"
          >
            {isBundling ? (
              <>
                <RefreshCw className="animate-spin" size={18} />
                <span>PAKOWANIE ZASOBÓW I GENEROWANIE ZIP...</span>
              </>
            ) : downloadSuccess ? (
              <>
                <CheckCircle2 size={18} className="text-emerald-400" />
                <span>POBRANO PLIK ZIP POMYŚLNIE!</span>
              </>
            ) : (
              <>
                <Download size={18} />
                <span>POBIERZ PACZKĘ ZIP (free-API-keys-radar-main.zip)</span>
              </>
            )}
          </button>

          <p className="text-[11px] font-mono text-zinc-500 text-center">
            Po pobraniu wystarczy wrzucić zawartość na GitHub, a proces Actions automatycznie skompiluje plik APK!
          </p>
        </div>
      </div>
    </div>
  );
};
