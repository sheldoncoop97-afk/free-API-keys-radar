package com.example.freeapiradar.data

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URI
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class ApiRepository(context: Context) {
    private val dao = ApiDatabase.get(context).apiDao()
    private val client = OkHttpClient.Builder()
        .callTimeout(20, TimeUnit.SECONDS)
        .connectTimeout(10, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    fun observe() = dao.observeAll()
    suspend fun count() = dao.count()

    // Public catalog files only. No secret scanning, credential extraction, or collection of exposed keys.
    private val catalogs = listOf(
        "https://raw.githubusercontent.com/public-apis/public-apis/master/README.md",
        "https://raw.githubusercontent.com/public-api-lists/public-api-lists/main/README.md",
        "https://raw.githubusercontent.com/free-public-apis/apis/main/README.md"
    )

    suspend fun scan(): Int {
        val now = System.currentTimeMillis()
        val found = mutableMapOf<String, ApiEntry>()
        catalogs.forEachIndexed { sourceIndex, url ->
            try {
                val req = Request.Builder().url(url).header("User-Agent", "FreeApiRadar-Android/1.0").build()
                client.newCall(req).execute().use { response ->
                    if (!response.isSuccessful) return@forEachIndexed
                    val body = response.body?.string().orEmpty()
                    val source = URI(url).host ?: "public catalog"
                    var category = "Other"
                    body.lineSequence().forEach { line ->
                        val heading = Regex("^#{1,4}\\s+(.+?)\\s*#*\\s*$").find(line)?.groupValues?.get(1)
                        if (heading != null) category = classify(heading)
                        if (!line.trim().startsWith("|") || line.count { it == '|' } < 4 || line.contains("---")) return@forEach
                        val cells = line.trim().trim('|').split('|').map { it.trim().trim('`') }
                        if (cells.size < 3) return@forEach
                        val name = cells[0].removeMarkdown().trim()
                        val desc = cells.getOrNull(1)?.removeMarkdown()?.trim().orEmpty()
                        if (name.isBlank() || name.equals("API", true) || name.length > 100 || desc.isBlank()) return@forEach
                        val link = Regex("https?://[^ )>]+")
                        val docs = link.find(cells[0])?.value ?: link.find(line)?.value ?: return@forEach
                        if (!docs.startsWith("https://")) return@forEach
                        val auth = cells.getOrNull(2)?.removeMarkdown()?.trim().orEmpty().ifBlank { "Unknown" }
                        val https = cells.getOrNull(3)?.removeMarkdown()?.trim().orEmpty().ifBlank { "Unknown" }
                        if (name.length < 2 || docs.contains("github.com/public-apis/public-apis/blob")) return@forEach
                        val id = sha256((name.lowercase() + "|" + docs.lowercase()))
                        val old = found[id]
                        found[id] = ApiEntry(
                            id = id, name = name, description = desc.take(500), category = if (category == "Other") classify("$name $desc") else category,
                            auth = auth, https = https, docsUrl = docs, source = source,
                            firstSeen = old?.firstSeen ?: now, lastSeen = now
                        )
                    }
                }
            } catch (_: Exception) { /* Keep scanning other sources if one is unavailable. */ }
        }
        if (found.isNotEmpty()) dao.upsertAll(found.values.toList())
        return found.size
    }

    suspend fun checkWebsite(entry: ApiEntry): String {
        return try {
            val request = Request.Builder().url(entry.docsUrl).header("User-Agent", "FreeApiRadar-Android/1.0").head().build()
            client.newCall(request).execute().use { response ->
                when {
                    response.code in 200..399 -> "Website responds (${response.code})"
                    response.code == 405 || response.code == 403 -> "Website reachable (${response.code})"
                    else -> "HTTP ${response.code}"
                }
            }
        } catch (e: Exception) { "Connection failed" }
    }

    suspend fun saveStatus(id: String, status: String) = dao.updateStatus(id, status, System.currentTimeMillis())

    private fun classify(text: String): String {
        val s = text.lowercase()
        return when {
            listOf("llm", "language model", "generative ai", "artificial intelligence", "machine learning", "ai ", "ai/", "inference", "embedding").any(s::contains) -> "AI & LLM"
            listOf("image", "text-to-image", "video", "animation", "diffusion").any(s::contains) -> "Image & Video"
            listOf("audio", "speech", "voice", "music", "transcription", "text-to-speech").any(s::contains) -> "Audio & Speech"
            listOf("automation", "workflow", "agent", "integration", "no-code").any(s::contains) -> "Automation & Agents"
            listOf("developer", "code", "programming", "github", "repository", "package").any(s::contains) -> "Developer Tools"
            else -> "Other"
        }
    }
    private fun String.removeMarkdown() = replace(Regex("\\[([^]]+)]\\([^)]*\\)"), "\u00241").replace("**", "").replace("*", "").replace("`", "").trim()
    private fun sha256(value: String) = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}
