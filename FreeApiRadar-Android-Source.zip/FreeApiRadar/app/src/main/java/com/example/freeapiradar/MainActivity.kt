package com.example.freeapiradar

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.FilterChip
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.freeapiradar.data.ApiEntry
import com.example.freeapiradar.data.ApiRepository
import com.example.freeapiradar.worker.ScanWorker
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        schedulePeriodicScan()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { RadarScreen(ApiRepository(applicationContext), ::runScan) } } }
    }

    private fun schedulePeriodicScan() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val periodic = PeriodicWorkRequestBuilder<ScanWorker>(12, TimeUnit.HOURS)
            .setConstraints(constraints).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("free-api-radar-periodic", ExistingPeriodicWorkPolicy.KEEP, periodic)
        // Run once soon after installation, rather than waiting for the first periodic window.
        WorkManager.getInstance(this).enqueue(OneTimeWorkRequestBuilder<ScanWorker>().setConstraints(constraints).build())
    }

    private fun runScan() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        WorkManager.getInstance(this).enqueue(OneTimeWorkRequestBuilder<ScanWorker>().setConstraints(constraints).build())
    }
}

@Composable
private fun RadarScreen(repo: ApiRepository, onScan: () -> Unit) {
    val apis by repo.observe().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var keyFilter by remember { mutableStateOf("All") }
    var scanning by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("First scan starts automatically. You can also scan now.") }
    val categories = listOf("All", "AI & LLM", "Image & Video", "Audio & Speech", "Automation & Agents", "Developer Tools", "Other")
    val visible = apis.filter { entry ->
        (selectedCategory == "All" || entry.category == selectedCategory) &&
        (keyFilter == "All" || (keyFilter == "No key" && !entry.needsKey) || (keyFilter == "Key needed" && entry.needsKey)) &&
        (query.isBlank() || "${entry.name} ${entry.description} ${entry.category}".contains(query, true))
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Free API Radar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Free AI, media, automation and developer APIs", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { scanning = true; message = "Scan queued. Results will appear as soon as the background task finishes."; onScan(); scanning = false }) { Text("Scan now") }
            Text("${apis.size} saved", style = MaterialTheme.typography.titleMedium)
        }
        Text(message, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        BasicTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp), decorationBox = { inner ->
            if (query.isEmpty()) Text("Search APIs, categories, descriptions…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            inner()
        })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "No key", "Key needed").forEach { option -> FilterChip(selected = keyFilter == option, onClick = { keyFilter = option }, label = { Text(option) }) }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text("Categories", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    categories.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            pair.forEach { cat -> FilterChip(selected = selectedCategory == cat, onClick = { selectedCategory = cat }, label = { Text(cat) }) }
                        }
                    }
                }
                Divider(Modifier.padding(vertical = 8.dp))
            }
            if (visible.isEmpty()) item { Text("No entries yet. Tap Scan now and check your connection.", modifier = Modifier.padding(16.dp)) }
            items(visible, key = { it.id }) { entry ->
                ApiCard(entry = entry, onCheck = {
                    scope.launch {
                        message = "Checking ${entry.name} website…"
                        val status = repo.checkWebsite(entry)
                        repo.saveStatus(entry.id, status)
                        message = "${entry.name}: $status. This tests the website, not the API's paid access or endpoint."
                    }
                })
            }
        }
    }
}

@Composable
private fun ApiCard(entry: ApiEntry, onCheck: () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(entry.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(entry.description, style = MaterialTheme.typography.bodyMedium)
            Text("${entry.category} · ${if (entry.needsKey) "Key/auth may be required: ${entry.auth}" else "No key indicated"} · HTTPS: ${entry.https}", style = MaterialTheme.typography.bodySmall)
            Text("Docs: ${entry.docsUrl}", style = MaterialTheme.typography.bodySmall)
            Text("Source: ${entry.source} · last catalog scan: ${DateFormat.getDateTimeInstance().format(Date(entry.lastSeen))}", style = MaterialTheme.typography.labelSmall)
            Text("Website status: ${entry.siteStatus}${if (entry.statusCheckedAt > 0) " · ${DateFormat.getDateTimeInstance().format(Date(entry.statusCheckedAt))}" else ""}", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onCheck) { Text("Check website") }
            }
        }
    }
}
