# Free API Radar (Android)

An Android starter app that periodically imports **public API catalog entries** and lets you filter them by category and whether authentication is indicated. It does **not** search for, collect, or store exposed API keys or other secrets.

## Features
- Kotlin + Jetpack Compose UI
- Room local database
- WorkManager background scan (12-hour periodic interval; Android may defer execution)
- Wi-Fi or mobile data via `NetworkType.CONNECTED`
- Local search and filters: category, key/no-key indication
- Manual scan button
- Optional website reachability check for an entry
- Notification after a background scan (Android 13+ asks for notification permission)

## Data sources
The app fetches public README catalog files from these GitHub repositories:
- `public-apis/public-apis`
- `public-api-lists/public-api-lists`
- `free-public-apis/apis`

Catalog availability and formats may change. The parser is intentionally best-effort. A source's `Auth` field is only an indication, not a guarantee that the service is free. A website check tests the documentation/homepage URL, not API functionality, quotas, or billing.

## Build an APK (Android Studio)
This workspace does not include a precompiled APK or a Gradle wrapper. Build the APK on a computer with Android Studio and JDK 17:
1. Install current Android Studio (with Android SDK Platform 35 and Build Tools).
2. Extract this folder.
3. Open the `FreeApiRadar` folder in Android Studio.
4. Allow Gradle sync and dependency downloads.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. The debug APK will normally be at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer the APK to your phone and install it. If Android asks, allow installation from that file manager.

Command line alternative from this folder after Gradle is installed:
```bash
gradle assembleDebug
```

## Project layout
- `app/src/main/AndroidManifest.xml` — permissions and launcher activity
- `app/src/main/java/com/example/freeapiradar/MainActivity.kt` — UI and WorkManager schedule
- `app/src/main/java/com/example/freeapiradar/data/ApiEntry.kt` — Room entity
- `app/src/main/java/com/example/freeapiradar/data/ApiDao.kt` — database queries
- `app/src/main/java/com/example/freeapiradar/data/ApiDatabase.kt` — local database
- `app/src/main/java/com/example/freeapiradar/data/ApiRepository.kt` — public catalog fetch, parsing and website check
- `app/src/main/java/com/example/freeapiradar/worker/ScanWorker.kt` — background scan and notification

## Limitations / next improvements
- Current parser is best-effort for Markdown tables and may need adapters as source repositories change.
- Category detection is keyword-based; some APIs will land in `Other`.
- The current implementation stores catalog metadata and a website status, not API keys. It does not automatically call arbitrary API endpoints or claim that an API is free based only on HTTP status.
- For a production release, add a detail screen with official pricing/free-tier links, pagination, user-selected source repositories, retry/backoff controls, and tests for each catalog parser.

## Automatyczna kompilacja APK na GitHubie

Repozytorium zawiera workflow `.github/workflows/android.yml`. Po wysłaniu projektu do repozytorium GitHub na gałąź `main` lub `master` kompilacja uruchomi się automatycznie. Można ją też uruchomić ręcznie.

1. Utwórz na GitHubie nowe repozytorium (np. `FreeApiRadar`).
2. Wgraj **zawartość** tego folderu projektu do repozytorium, zachowując folder `.github/workflows` (w GitHubie włącz pokazywanie ukrytych plików, jeśli przesyłasz przez narzędzie, które je ukrywa). Najpewniejsza metoda to przesłanie ZIP-a do repozytorium i rozpakowanie go lokalnie, a następnie wgranie plików; GitHub nie kompiluje ZIP-a tylko dlatego, że został dodany jako plik.
3. Otwórz kartę **Actions** i wybierz `Build Free API Radar APK`. Przy pierwszym uruchomieniu zatwierdź włączenie GitHub Actions, jeśli GitHub o to poprosi.
4. Po zakończeniu zadania otwórz jego przebieg i pobierz artefakt **FreeApiRadar-debug-apk** z sekcji **Artifacts**. W środku będzie `app-debug.apk`.

Workflow korzysta z JDK 17 i Gradle 8.9 oraz zachowuje APK jako artefakt przez 14 dni. Jeśli kompilacja zakończy się błędem, otwórz log zadania w zakładce Actions — pokaże konkretny błąd do naprawienia. APK debugowe nie jest podpisanym wydaniem produkcyjnym.
