# Changelog — Umbrella Corp

## 1.4.0 — Professional interface refresh
- Rebuilt the main screen around a responsive dark research-console layout with consistent spacing, restrained red accents, status panels, metrics and a horizontally scrolling category selector.
- Fixed the narrow-screen counter overflow by giving the action buttons and metrics explicit flexible widths.
- Added a real scan lifecycle state: the scan button stays busy while its WorkManager request runs and reports completion, newly discovered entries, cancellation or failure.
- Kept initial and 15-minute periodic background scanning, network constraints and new-entry notifications.
- Made “CHECK + OPEN” check the documentation endpoint off the main thread, update its status and then open the actual page in the browser.
- Refined source management and empty-catalog states.
- Added a privacy-policy draft and Google Play listing/release checklist.
- Bumped version to 1.4.0 (versionCode 5).

## 1.3 — Umbra Watch
- Packaged the Android project and existing catalog features.
- Added Umbrella branding, splash art and startup audio.
- Added public catalog scanning, source management, notifications and browser-opening fallback.
