# Google Play listing draft — Umbrella Corp

## Short description
Discover public API catalogs and free-tier AI/API access leads in one searchable dashboard.

## Full description
Umbrella Corp is a research dashboard for exploring public API directories, AI/LLM provider pages, and developer tools.

**Features**
- Search and filter a catalog by category and authentication hints.
- Review provider documentation and open the official website in your browser.
- Add or remove public HTTPS Markdown catalog sources.
- Run a manual scan and see completion feedback.
- Schedule background catalog checks when Android permits and the device is online.
- Receive a notification when new catalog entries are discovered, if notifications are enabled.

**Please note:** A listing is a discovery lead, not a guarantee that an API is free, available in your country, or suitable for production. Provider quotas and terms change. Check the official provider page before use. The app does not provide API keys and does not collect leaked credentials.

## Before submitting to Google Play
- Publish the privacy policy at a stable public HTTPS URL and replace the contact placeholder.
- Complete the Data safety form based on the final release build and SDK behavior.
- Provide a support email and store screenshots made from the final release build.
- Use a signed release AAB/APK with a protected upload key; do not publish the debug APK.
- Confirm ownership/permission for the Umbrella Corporation branding and all artwork/audio. The included Resident Evil 2 Save Room recording and franchise-associated branding may require licenses and can create a rejection/takedown risk if used without permission. Replace them with original or properly licensed assets unless permission is confirmed.
- Test on real devices, including first launch, denied notification permission, offline scan, source add/remove, browser opening, screen sizes, and accessibility/font scaling.
