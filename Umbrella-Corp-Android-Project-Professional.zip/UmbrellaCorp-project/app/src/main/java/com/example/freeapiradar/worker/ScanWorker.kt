package com.example.freeapiradar.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.freeapiradar.data.ApiRepository

class ScanWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        setProgress(workDataOf(KEY_STAGE to "connecting"))
        val repo = ApiRepository(applicationContext)
        val sources = repo.configuredSourceCount()
        setProgress(workDataOf(KEY_STAGE to "scanning", KEY_SOURCES to sources))
        val added = repo.scan()
        if (added > 0) notifyResult("UMBRA: new API entries detected", "$added new catalog entries were found. Open Umbrella Corp to review them.")
        Result.success(workDataOf(KEY_ADDED to added, KEY_SOURCES to sources))
    } catch (_: Exception) {
        Result.failure(workDataOf(KEY_ERROR to "scan_failed"))
    }

    private fun notifyResult(title: String, text: String) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel("api_radar", "Umbrella Corp alerts", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val notification = NotificationCompat.Builder(applicationContext, "api_radar")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .build()
        try { manager.notify(1201, notification) } catch (_: SecurityException) { }
    }

    companion object {
        const val KEY_ADDED = "added_count"
        const val KEY_SOURCES = "source_count"
        const val KEY_STAGE = "scan_stage"
        const val KEY_ERROR = "scan_error"
    }
}
