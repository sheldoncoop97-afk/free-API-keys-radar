package com.example.freeapiradar

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.example.freeapiradar.data.ApiEntry
import com.example.freeapiradar.data.ApiRepository
import com.example.freeapiradar.worker.ScanWorker
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

private val UmbrellaRed = Color(0xFFE51B32)
private val UmbrellaRedDark = Color(0xFF9E1022)
private val UmbrellaBlack = Color(0xFF08090C)
private val UmbrellaPanel = Color(0xFF12151B)
private val UmbrellaPanelRaised = Color(0xFF191D25)
private val UmbrellaWhite = Color(0xFFF4F5F7)
private val UmbrellaMuted = Color(0xFF9AA2AE)
private val UmbrellaLine = Color(0xFF292E38)
private val UmbrellaCyan = Color(0xFF72D9E8)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private var introPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 9, 12)
        window.navigationBarColor = android.graphics.Color.rgb(8, 9, 12)
        schedulePeriodicScan()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            val colors = darkColorScheme(
                primary = UmbrellaRed, onPrimary = Color.White,
                background = UmbrellaBlack, onBackground = UmbrellaWhite,
                surface = UmbrellaPanel, onSurface = UmbrellaWhite,
                secondary = UmbrellaCyan, outline = UmbrellaLine
            )
            MaterialTheme(colorScheme = colors) {
                Surface(Modifier.fillMaxSize(), color = UmbrellaBlack) {
                    var showSplash by remember { mutableStateOf(true) }
                    LaunchedEffect(Unit) {
                        try {
                            introPlayer = MediaPlayer.create(this@MainActivity, R.raw.umbrella_intro)
                            introPlayer?.start()
                        } catch (_: Exception) { }
                        delay(6200)
                        showSplash = false
                        introPlayer?.let { player ->
                            try { if (player.isPlaying) player.pause(); player.seekTo(0) } catch (_: Exception) { }
                        }
                    }
                    Box(Modifier.fillMaxSize()) {
                        RadarScreen(
                            repo = ApiRepository(applicationContext),
                            onScan = ::runScan,
                            openWebsite = ::openWebsite
                        )
                        AnimatedVisibility(
                            visible = showSplash,
                            enter = fadeIn(tween(250)),
                            exit = fadeOut(tween(550))
                        ) { UmbrellaSplash() }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        introPlayer?.run { try { if (isPlaying) stop() } catch (_: Exception) { }; release() }
        super.onDestroy()
    }

    private fun openWebsite(url: String) {
        try {
            val uri = Uri.parse(url.trim())
            if (uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) {
                Toast.makeText(this, "Nieprawidłowy adres strony", Toast.LENGTH_SHORT).show()
                return
            }
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.android.chrome") })
            } catch (_: Exception) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (_: Exception) {
                    Toast.makeText(this, "Nie znaleziono przeglądarki internetowej", Toast.LENGTH_LONG).show()
                }
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Nie udało się otworzyć strony", Toast.LENGTH_LONG).show()
        }
    }

    private fun schedulePeriodicScan() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val periodic = PeriodicWorkRequestBuilder<ScanWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .addTag("umbrella-periodic-scan")
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "umbrella-periodic-scan", ExistingPeriodicWorkPolicy.KEEP, periodic
        )
        val initial = OneTimeWorkRequestBuilder<ScanWorker>().setConstraints(constraints).addTag("umbrella-initial-scan").build()
        WorkManager.getInstance(this).enqueueUniqueWork("umbrella-initial-scan", ExistingWorkPolicy.KEEP, initial)
    }

    private fun runScan(): UUID {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val request = OneTimeWorkRequestBuilder<ScanWorker>()
            .setConstraints(constraints)
            .addTag("umbrella-manual-scan")
            .build()
        WorkManager.getInstance(this).enqueueUniqueWork(
            "umbrella-manual-scan", ExistingWorkPolicy.REPLACE, request
        )
        return request.id
    }
}

@Composable
private fun UmbrellaSplash() {
    var reveal by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(100); reveal = true }
    val alpha by animateFloatAsState(if (reveal) 1f else 0f, tween(800), label = "splashAlpha")
    Box(Modifier.fillMaxSize().background(UmbrellaBlack), contentAlignment = Alignment.Center) {
        Image(
            painter = painterResource(R.drawable.umbrella_splash),
            contentDescription = "Umbrella Corporation",
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxWidth().aspectRatio(1536f / 1365f).alpha(alpha)
        )
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 24.dp).alpha(alpha),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LinearProgressIndicator(
                modifier = Modifier.width(104.dp).height(2.dp),
                color = UmbrellaRed,
                trackColor = UmbrellaLine
            )
            Text("WELCOME TO UMBRELLA CORPORATION", color = UmbrellaCyan, fontSize = 9.sp, letterSpacing = 2.sp)
            Text("SECURE CONNECTION // INITIALIZING", color = UmbrellaMuted, fontSize = 8.sp, letterSpacing = 1.5.sp)
        }
    }
}

@Composable
private fun RadarScreen(repo: ApiRepository, onScan: () -> UUID, openWebsite: (String) -> Unit) {
    val context = LocalContext.current
    val apis by repo.observe().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var keyFilter by remember { mutableStateOf("All") }
    var scanning by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Network ready. Start a scan to refresh the catalog.") }
    var showSources by remember { mutableStateOf(false) }
    var sourceInput by remember { mutableStateOf("") }
    var customSources by remember { mutableStateOf(repo.customSources()) }
    var lastScanId by remember { mutableStateOf<UUID?>(null) }
    var checkedEntryId by remember { mutableStateOf<String?>(null) }
    val categories = listOf("All", "AI & LLM", "Image & Video", "Audio & Speech", "Automation & Agents", "Developer Tools", "Other")
    val visible = apis.filter { entry ->
        (selectedCategory == "All" || entry.category == selectedCategory) &&
            (keyFilter == "All" || (keyFilter == "No key" && !entry.needsKey) || (keyFilter == "Key needed" && entry.needsKey)) &&
            (query.isBlank() || "${entry.name} ${entry.description} ${entry.category}".contains(query, true))
    }

    LaunchedEffect(lastScanId) {
        val id = lastScanId ?: return@LaunchedEffect
        scanning = true
        message = "Connecting to public catalogs…"
        val wm = WorkManager.getInstance(context.applicationContext)
        // WorkManager is observed by polling the specific request, so the button reports real completion.
        while (true) {
            val info = try { withContext(Dispatchers.IO) { wm.getWorkInfoById(id).get() } } catch (_: Exception) { null }
            when (info?.state) {
                WorkInfo.State.SUCCEEDED -> {
                    val added = info.outputData.getInt(ScanWorker.KEY_ADDED, 0)
                    val scanned = info.outputData.getInt(ScanWorker.KEY_SOURCES, 0)
                    scanning = false
                    message = if (added > 0) "Scan complete. $added new entries found across $scanned sources." else "Scan complete. No new entries found; catalog is up to date."
                    return@LaunchedEffect
                }
                WorkInfo.State.FAILED -> {
                    scanning = false
                    message = "Scan failed. Check your connection and try again."
                    return@LaunchedEffect
                }
                WorkInfo.State.CANCELLED -> {
                    scanning = false
                    message = "Scan cancelled."
                    return@LaunchedEffect
                }
                else -> {
                    message = when (info?.state) {
                        WorkInfo.State.ENQUEUED -> "Scan queued — waiting for network…"
                        WorkInfo.State.BLOCKED -> "Waiting for another task…"
                        else -> "Scanning public catalogs…"
                    }
                    delay(650)
                }
            }
        }
    }

    Column(Modifier.fillMaxSize().background(UmbrellaBlack)) {
        Column(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 10.dp, bottom = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Image(
                    painter = painterResource(R.drawable.umbrella_icon),
                    contentDescription = "Umbrella emblem",
                    modifier = Modifier.size(54.dp).clip(RoundedCornerShape(12.dp))
                )
                Column(Modifier.weight(1f)) {
                    Text("UMBRELLA CORP", fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp, color = UmbrellaWhite, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("FREE API RADAR", fontSize = 11.sp, color = UmbrellaRed, fontWeight = FontWeight.Bold, letterSpacing = 2.2.sp)
                    Text("RESEARCH & DEVELOPMENT // 01", fontSize = 8.sp, color = UmbrellaMuted, letterSpacing = 1.2.sp)
                }
                Box(Modifier.size(9.dp).background(Color(0xFF43D18B), CircleShape))
            }
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { if (!scanning) lastScanId = onScan() },
                    enabled = !scanning,
                    modifier = Modifier.weight(1.12f).height(52.dp),
                    shape = RoundedCornerShape(13.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed, disabledContainerColor = UmbrellaRedDark)
                ) {
                    if (scanning) CircularProgressIndicator(Modifier.size(17.dp), color = Color.White, strokeWidth = 2.dp)
                    else Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (scanning) "SCANNING" else "SCAN NOW", fontWeight = FontWeight.Bold, letterSpacing = 1.sp, maxLines = 1)
                }
                OutlinedButton(
                    onClick = { customSources = repo.customSources(); showSources = true },
                    modifier = Modifier.weight(1f).height(52.dp),
                    shape = RoundedCornerShape(13.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, UmbrellaLine),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = UmbrellaRed, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("MY SOURCES", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    Spacer(Modifier.width(5.dp))
                    Text("${customSources.size}", color = UmbrellaRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                MetricCard("CATALOG ENTRIES", apis.size.toString(), Modifier.weight(1f), UmbrellaCyan)
                MetricCard("CATEGORIES", categories.size.minus(1).toString(), Modifier.weight(1f), UmbrellaRed)
                MetricCard("SAVED SOURCES", customSources.size.toString(), Modifier.weight(1f), Color(0xFFB9A0FF))
            }
            Spacer(Modifier.height(12.dp))
            Surface(
                color = UmbrellaPanel,
                shape = RoundedCornerShape(11.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, UmbrellaLine)
            ) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Box(Modifier.padding(top = 3.dp).size(7.dp).background(if (scanning) UmbrellaCyan else UmbrellaRed, CircleShape))
                    Column(Modifier.weight(1f)) {
                        Text(if (scanning) "NETWORK SCAN IN PROGRESS" else "SYSTEM STATUS", color = if (scanning) UmbrellaCyan else UmbrellaRed, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                        Spacer(Modifier.height(3.dp))
                        Text(message, color = UmbrellaMuted, fontSize = 12.sp, lineHeight = 17.sp)
                        Spacer(Modifier.height(5.dp))
                        Text("AUTO-SCAN · 15 MIN MINIMUM · PUBLIC CATALOGS + FREE-TIER LEADS", color = UmbrellaMuted, fontSize = 8.sp, letterSpacing = 0.4.sp)
                    }
                }
            }
            Spacer(Modifier.height(13.dp))
            Surface(color = UmbrellaPanel, shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, UmbrellaLine)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, contentDescription = null, tint = UmbrellaMuted, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.weight(1f).padding(vertical = 12.dp)) {
                        if (query.isEmpty()) Text("Search APIs, models, providers…", color = UmbrellaMuted, fontSize = 13.sp)
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyMedium.copy(color = UmbrellaWhite, fontSize = 13.sp),
                            cursorBrush = androidx.compose.ui.graphics.SolidColor(UmbrellaRed)
                        )
                    }
                    if (query.isNotEmpty()) Text("CLEAR", color = UmbrellaRed, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { query = "" }.padding(7.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Tune, contentDescription = null, tint = UmbrellaMuted, modifier = Modifier.size(16.dp))
                listOf("All", "No key", "Key needed").forEach { option ->
                    val selected = keyFilter == option
                    Surface(
                        modifier = Modifier.clickable { keyFilter = option },
                        color = if (selected) UmbrellaRed.copy(alpha = 0.16f) else UmbrellaPanel,
                        shape = RoundedCornerShape(9.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) UmbrellaRed.copy(alpha = 0.8f) else UmbrellaLine)
                    ) {
                        Text(option.uppercase(), modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp), color = if (selected) UmbrellaWhite else UmbrellaMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp, maxLines = 1)
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("${visible.size} FOUND", color = UmbrellaMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }

        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(start = 18.dp, end = 18.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            categories.forEach { category ->
                val selected = selectedCategory == category
                Surface(
                    modifier = Modifier.clickable { selectedCategory = category },
                    shape = RoundedCornerShape(8.dp),
                    color = if (selected) UmbrellaWhite else UmbrellaPanel,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) UmbrellaWhite else UmbrellaLine)
                ) {
                    Text(category, modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp), color = if (selected) UmbrellaBlack else UmbrellaMuted, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("CATALOG DATABASE", color = UmbrellaWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
            Spacer(Modifier.weight(1f))
            Text("LIVE FILTER · ${visible.size} ITEMS", color = UmbrellaMuted, fontSize = 8.sp, letterSpacing = 0.7.sp)
        }
        Spacer(Modifier.height(7.dp))
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 26.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (visible.isEmpty()) {
                item {
                    Surface(color = UmbrellaPanel, shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, UmbrellaLine)) {
                        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = UmbrellaRed, modifier = Modifier.size(30.dp))
                            Text(if (apis.isEmpty()) "CATALOG NOT INITIALIZED" else "NO MATCHING ENTRIES", color = UmbrellaWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(if (apis.isEmpty()) "Connect to the internet and run a scan to populate the database." else "Try another search term or reset the filters.", color = UmbrellaMuted, fontSize = 12.sp)
                            if (apis.isEmpty()) Button(onClick = { if (!scanning) lastScanId = onScan() }, enabled = !scanning, colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed)) { Text("INITIALIZE SCAN") }
                        }
                    }
                }
            }
            items(visible, key = { it.id }) { entry ->
                ApiCard(
                    entry = entry,
                    checking = checkedEntryId == entry.id,
                    onCheck = {
                        scope.launch {
                            checkedEntryId = entry.id
                            message = "Opening ${entry.name} and checking its website…"
                            // The action both checks the page and opens the actual provider/docs page.
                            val status = withContext(Dispatchers.IO) { repo.checkWebsite(entry) }
                            repo.saveStatus(entry.id, status)
                            message = "${entry.name}: $status. API quotas and eligibility depend on the provider's current terms."
                            checkedEntryId = null
                            openWebsite(entry.docsUrl)
                        }
                    },
                    onOpenWebsite = { openWebsite(entry.docsUrl) }
                )
            }
        }
    }

    if (showSources) {
        AlertDialog(
            onDismissRequest = { showSources = false },
            containerColor = UmbrellaPanelRaised,
            titleContentColor = UmbrellaWhite,
            textContentColor = UmbrellaMuted,
            title = {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("OBSERVED SOURCES", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    Text("UMBRELLA // NETWORK CONFIGURATION", color = UmbrellaRed, fontSize = 9.sp, letterSpacing = 1.sp)
                }
            },
            text = {
                Column(Modifier.heightIn(max = 440.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Add a public HTTPS catalog in Markdown format (tables or linked lists are supported). JSON/API feeds may need a compatible public format. Sources are saved on this device.", fontSize = 12.sp, lineHeight = 17.sp)
                    Text("The catalog lists access leads, not guarantees. Free quotas, availability and regional eligibility can change. The app never collects leaked or stolen keys.", color = UmbrellaRed, fontSize = 11.sp, lineHeight = 16.sp)
                    OutlinedTextField(
                        value = sourceInput,
                        onValueChange = { sourceInput = it },
                        label = { Text("Public HTTPS source URL") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                    Button(
                        onClick = {
                            if (repo.addCustomSource(sourceInput)) {
                                sourceInput = ""
                                customSources = repo.customSources()
                                showSources = false
                                lastScanId = onScan()
                                message = "Source saved. Starting a catalog scan…"
                            } else {
                                message = "Invalid source URL. Enter a complete HTTPS address."
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed),
                        shape = RoundedCornerShape(10.dp)
                    ) { Icon(Icons.Default.Add, contentDescription = null); Spacer(Modifier.width(7.dp)); Text("ADD SOURCE & SCAN") }
                    if (customSources.isNotEmpty()) {
                        Text("SAVED ON THIS DEVICE · ${customSources.size}", color = UmbrellaRed, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.sp)
                        customSources.forEach { source ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(source, modifier = Modifier.weight(1f), color = UmbrellaWhite, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                TextButton(onClick = { repo.removeCustomSource(source); customSources = repo.customSources() }) { Text("REMOVE", color = UmbrellaRed, fontSize = 10.sp) }
                            }
                            HorizontalDivider(color = UmbrellaLine)
                        }
                    } else Text("No custom sources configured yet.", color = UmbrellaMuted, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showSources = false }) { Text("CLOSE", color = UmbrellaWhite) } }
        )
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier, accent: Color) {
    Surface(
        modifier = modifier,
        color = UmbrellaPanel,
        shape = RoundedCornerShape(11.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, UmbrellaLine)
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, color = UmbrellaMuted, fontSize = 7.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(value, color = accent, fontSize = 21.sp, fontWeight = FontWeight.Black, maxLines = 1)
        }
    }
}

@Composable
private fun ApiCard(entry: ApiEntry, checking: Boolean, onCheck: () -> Unit, onOpenWebsite: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(containerColor = UmbrellaPanel),
        border = androidx.compose.foundation.BorderStroke(1.dp, UmbrellaLine)
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.width(3.dp).height(42.dp).clip(CircleShape).background(UmbrellaRed))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(entry.name, color = UmbrellaWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold, lineHeight = 20.sp)
                    Text(entry.category.uppercase(), color = UmbrellaRed, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                }
                Surface(color = if (entry.needsKey) Color(0xFF302718) else Color(0xFF183329), shape = RoundedCornerShape(6.dp)) {
                    Text(if (entry.needsKey) "KEY / ACCOUNT" else "NO KEY", modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp), color = if (entry.needsKey) Color(0xFFF2C875) else Color(0xFF7CE0AC), fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
            Text(entry.description, color = Color(0xFFD2D6DD), fontSize = 12.sp, lineHeight = 17.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                TinyTag("HTTPS ${entry.https}")
                TinyTag("ACCESS ${entry.auth.ifBlank { "UNKNOWN" }}")
            }
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("DOCUMENTATION", color = UmbrellaMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(entry.docsUrl, color = UmbrellaCyan, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            HorizontalDivider(color = UmbrellaLine)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("SOURCE  ·  ${entry.source}", color = UmbrellaMuted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("UPDATED  ·  ${DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(entry.lastSeen))}", color = UmbrellaMuted, fontSize = 9.sp)
                    Text("STATUS  ·  ${entry.siteStatus}${if (entry.statusCheckedAt > 0) " / ${DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(entry.statusCheckedAt))}" else ""}", color = if (entry.siteStatus.startsWith("Website responds") || entry.siteStatus.startsWith("Website reachable")) Color(0xFF7CE0AC) else UmbrellaMuted, fontSize = 9.sp)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onOpenWebsite,
                    modifier = Modifier.weight(1f).height(43.dp),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed)
                ) {
                    Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("OPEN WEBSITE", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.3.sp, maxLines = 1)
                }
                OutlinedButton(
                    onClick = onCheck,
                    enabled = !checking,
                    modifier = Modifier.weight(1f).height(43.dp),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, UmbrellaLine)
                ) {
                    if (checking) CircularProgressIndicator(Modifier.size(14.dp), color = UmbrellaRed, strokeWidth = 2.dp)
                    else Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(15.dp), tint = UmbrellaRed)
                    Spacer(Modifier.width(6.dp))
                    Text(if (checking) "CHECKING" else "CHECK + OPEN", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun TinyTag(value: String) {
    Surface(color = UmbrellaPanelRaised, shape = RoundedCornerShape(6.dp), border = androidx.compose.foundation.BorderStroke(1.dp, UmbrellaLine)) {
        Text(value.uppercase(), modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp), color = UmbrellaMuted, fontSize = 8.sp, maxLines = 1)
    }
}
