# Umbrella Corp — Privacy Policy

**Draft for review before publication.** Replace the contact placeholder and publish this policy at a stable public HTTPS URL before submitting the app to Google Play.

**Effective date:** 17 October 2026  
**App:** Umbrella Corp  
**Contact:** [ADD A REAL SUPPORT EMAIL ADDRESS]

## Information the app handles

Umbrella Corp stores its API catalog database and any custom catalog URLs locally on the device. When a scan is run, the app requests public catalog files and documentation pages from the configured source hosts. Those hosts may receive standard connection information, such as the device's IP address and request metadata, as part of normal HTTPS communication.

The app does not ask for or collect API secrets, passwords, payment information, contacts, precise location, or advertising identifiers. It does not intentionally collect leaked or stolen API keys. The current project contains no analytics or advertising SDK.

## Notifications and background work

The app can check public catalogs in the background when Android's WorkManager permits it and the device has a network connection. Android may delay scheduled work to conserve battery. If notifications are permitted, the app may show a notification when a scan detects new catalog entries.

## Custom sources

Custom source URLs are stored on the device. When a scan runs, the app requests those URLs. Only add sources you trust and are authorized to access.

## Third-party services

Catalog and provider links lead to third-party websites. Opening a link transfers the user to that provider's website, which is governed by that provider's own privacy policy and terms. Umbrella Corp does not control those services.

## Data retention and deletion

Catalog data and custom source URLs remain on the device until removed by the user or until app data is cleared/uninstalled. The app developer does not receive a copy of the local database through an app backend.

## Children

The app is a developer research utility and is not designed specifically for children.

## Changes and contact

This policy may be updated if the app's data practices change. For privacy questions, contact the support email listed above.
