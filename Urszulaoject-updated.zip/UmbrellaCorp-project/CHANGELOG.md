# Changelog — Umbrella Corp

## Umbra Watch 1.4 — Full Reference Concept UI & Functional Refresh
- **4-Phase Cinematic Startup Animation**: Implemented 4-stage boot sequence matching concept reference sheet (0-1.5s matrix initialization, 1.5-3s rotating wireframe logo formation, 3-5s metallic emblem & typography reveal, 5-7.5s Raccoon City skyscraper storm finale with audio and spoken voiceover).
- **Skip Sequence Control**: Added instant "SKIP" button in boot sequence.
- **Image to Video & Motion Hub**: Added dedicated category for generative AI video models (Luma Dream Machine, Runway Gen-3, Kling AI, Pika Labs, Stable Video Diffusion SVD).
- **18+ Classified Separate Space**: Added restricted adult and NSFW category protected by a Level 4 Biohazard age-verification gate with separate quarantine mode.
- **API Details Screen & Response Example**: Added comprehensive modal showing rate limits, authentication badges, documentation viewer, and syntax-highlighted JSON Response Example block matching the concept sheet.
- **Side Navigation Drawer**: Added slide-out menu with navigation items and world map footer with glowing Umbrella emblem and "OUR BUSINESS IS LIFE ITSELF".
- **Bottom Navigation Bar**: Added fixed mobile bottom navigation (Home, Favorites, Sources, Settings).
- **Package Visibility**: Added Android 11+ `<queries>` in `AndroidManifest.xml` for reliable browser opening.
- **Database Hardening**: Added `.fallbackToDestructiveMigration()` in Room builder.
- **Automated APK Build**: Verified GitHub Actions CI workflow `.github/workflows/android.yml` for one-click compilation of `app-debug.apk`.

## Umbra Watch 1.3 — packaged project
- Consolidated the Android source into a standalone Android Studio project.
- Set the launcher/app label to **Umbrella Corp**.
- Updated the main in-app heading to **UMBRELLA CORP**.
- Fixed the website button callback so catalog entries pass their documentation URL to the activity.
- Updated link opening to try Chrome first and then the default/available browser.
- Added a standalone GitHub Actions workflow that builds and uploads `Umbrella-Corp-debug-apk`.
- Preserved the existing Umbrella logo, startup animation/audio, catalog scanning, MY SOURCES, notifications and 15-minute WorkManager configuration.

## Result management checkpoint
- Added local persistent URL bookmarks from catalog result cards.
- Added a Saved URLs dialog with Open and Delete actions.
- Added confirmed Remove Result action; hidden result IDs persist locally and stay filtered after later catalog scans.
- Kept catalog scanning, categories, key filters, website checks, custom sources, splash artwork, and startup audio.
