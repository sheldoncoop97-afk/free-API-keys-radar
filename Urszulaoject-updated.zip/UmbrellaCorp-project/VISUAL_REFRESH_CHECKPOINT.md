# Umbrella Corporation — Visual Refresh (non-final checkpoint)

This ZIP is a working visual-refresh iteration of the existing Android project. It is **not the final release**.

## Applied visual changes
- Separate custom red/white Umbrella emblem for the launcher/app icon (not reused as the splash photograph).
- Portrait startup artwork resized to 1080×1920 for modern phone screens and displayed with crop-to-fill.
- Separate dark laboratory background at 1080×1920 for the app interior, dimmed in the UI so text/cards remain readable.
- Small red monospaced boot text appears at the upper-left and types character-by-character during startup:
  `Whit our corporation you can fell safe and secure your life is our business .`
- Existing startup music resource `app/src/main/res/raw/umbrella_intro.mp3` is retained; the startup music remains attached to launch, not to the background image.
- Updated adaptive launcher foreground to a red/white segmented Umbrella emblem.
- Existing scanning, periodic scan scheduling, custom HTTPS sources, website opening/status checks, API repository/database and worker code have not intentionally been removed.

## Asset dimensions
- App icon master: 512×512 PNG.
- Additional icon sizes: 192, 144, 96, 72, 48, 36 and 24 px.
- Splash artwork: 1080×1920 JPEG (portrait 9:16).
- Interior background: 1080×1920 JPEG (separate image, darker for legibility).
- Transparent emblem: 512×512 PNG.

## Important status
- This package has not been confirmed by a successful Android build or GitHub Actions run in this step.
- The phrase in the startup animation preserves the spelling supplied in the request; it can be corrected in a later non-final iteration if desired.
- No API functionality or workflow success is claimed solely from editing these files.


## Added — result management (working checkpoint)
- Each result card has **SAVE URL** and **REMOVE RESULT** actions.
- Saved website URLs are stored locally and remain available after restarting the app; the **SAVED URLS** dialog can open or delete a saved address.
- Removing a result asks for confirmation and stores its ID in local preferences, filtering it out in later scans on this device.
- Existing categories, key filters, scanning, website checks, custom source management, intro music, and startup visual effects remain in the project.
- This checkpoint still requires a successful Android build/run to confirm compilation and runtime behavior.
