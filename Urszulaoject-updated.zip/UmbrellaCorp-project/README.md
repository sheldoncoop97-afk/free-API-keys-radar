# Umbrella Corp — Android project

**Official app name:** Umbrella Corp  
**Project edition:** Umbra Watch 1.4 — result management + Chrome/browser-opening fix  
**Package ID:** `com.example.freeapiradar`

This is the complete Android Studio project for the working Umbrella Corp app. The launcher name is **Umbrella Corp**. The in-app branding uses the Umbrella Corp name while retaining Free API Radar as a description of the catalog feature.

## Features included

- **4-Phase Cinematic Startup Sequence**: 0-1.5s matrix initialization, 1.5-3s rotating wireframe logo formation, 3-5s metallic emblem & typography reveal, 5-7.5s Raccoon City skyscraper storm finale with audio and spoken voiceover ("Welcome to Umbrella Corporation. Our business is life itself."). Includes a top-right **SKIP [ESC]** button.
- **Image to Video & Motion Hub**: Curated video diffusion models and inference APIs (Luma Dream Machine, Runway Gen-3, Kling AI, Pika Labs, Stable Video Diffusion SVD).
- **18+ Classified Separate Space**: Dedicated adult and NSFW category protected by a Level 4 Biohazard age-verification gate with separate quarantine mode (Waifu.it, Sightengine, HuggingFace NSFW, Uncensored LLMs).
- **API Details Screen & JSON Response Example**: Comprehensive dossier view showing rate limits, authentication badges, documentation viewer, and syntax-highlighted JSON Response Example block matching the concept sheet.
- **Side Navigation Drawer**: Slide-out menu with navigation items and world map footer with glowing Umbrella emblem and "OUR BUSINESS IS LIFE ITSELF".
- **Bottom Navigation Bar**: Fixed mobile bottom navigation (Home, Favorites, Sources, Settings).
- Public API catalog scanning and filtering by category and whether an API indicates authentication.
- Directory feeds for free AI/LLM API opportunities and provider registration pages; current free quotas must be checked on the provider's own site.
- **MY SOURCES**: add/remove public HTTPS Markdown catalog sources.
- Background checks using Android WorkManager, configured for 15-minute intervals when network is available. Android battery policies can delay execution.
- Notifications when new catalog entries are detected, subject to Android notification permission.
- Website links: the app first tries Chrome (`com.android.chrome`), then falls back to another available browser. Includes package visibility queries for Android 11+.
- **SAVE URL** on a result stores its website address locally; **SAVED URLS** lists saved addresses, lets you open them, and delete bookmarks. Saved addresses persist across app restarts.
- **REMOVE RESULT** hides a used result after confirmation. Hidden result IDs are stored locally, so the same catalog entry stays hidden during later scans on this device.
- The app handles public catalog metadata; it does not search for or collect leaked API keys.

## Build APK on GitHub

The project includes `.github/workflows/android.yml` for GitHub Actions.

1. Extract this ZIP.
2. Upload the **contents of this project folder** to the root of your GitHub repository (including the hidden `.github` folder), or commit the folder's contents using Git.
3. Open the repository's **Actions** tab and run **Build Umbrella Corp APK**. A push to `main`/`master` that changes source files also triggers a build.
4. Open the successful workflow run and download the artifact **Umbrella-Corp-debug-apk**.
5. Extract that artifact ZIP and install `app-debug.apk` on the phone. If Android asks, allow the app used to open the APK to install unknown apps.

The workflow uses JDK 17, Android SDK Platform 35 and Gradle 8.9. GitHub retains the APK artifact for 14 days. This project ZIP contains source code and build configuration; it does not contain a compiled APK.

## Build locally

Open this folder in Android Studio with JDK 17 and Android SDK Platform 35 installed. Alternatively, with Gradle 8.9 and the Android SDK configured, run from this directory:

```bash
gradle assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Important files

- `app/src/main/AndroidManifest.xml` — Android app label and permissions.
- `app/src/main/java/com/example/freeapiradar/MainActivity.kt` — app UI, splash screen and browser-opening logic.
- `app/src/main/java/com/example/freeapiradar/data/` — database and public catalog fetching/parsing.
- `app/src/main/java/com/example/freeapiradar/worker/ScanWorker.kt` — background scans and notifications.
- `app/src/main/res/drawable/umbrella_logo.xml` — logo.
- `app/src/main/res/raw/umbrella_intro.wav` — intro sound.
- `.github/workflows/android.yml` — automated APK build.

## Notes

- The Android package/application ID remains `com.example.freeapiradar` to preserve the identity of the currently installed app. The displayed launcher name is `Umbrella Corp`.
- This is a debug APK workflow, not a Play Store release/signing pipeline.
- Provider free tiers, registration rules and availability can change; verify them on official provider pages.


## Umbrella visual refresh
- Uses the supplied full-screen Umbrella boot graphic (including all original text).
- Launcher/app mark uses a crop of the Umbrella emblem.
- Startup audio uses the supplied Resident Evil 2 Save Room MP3 and stops when the splash closes.
