package com.example.freeapiradar

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.work.*
import com.example.freeapiradar.data.ApiEntry
import com.example.freeapiradar.data.ApiRepository
import com.example.freeapiradar.worker.ScanWorker
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

val UmbrellaRed = Color(0xFFE50922)
val UmbrellaRedGlow = Color(0xFFFF3349)
val UmbrellaBlack = Color(0xFF08090C)
val UmbrellaPanel = Color(0xFF15171C)
val UmbrellaPanelBorder = Color(0xFF282B33)
val UmbrellaWhite = Color(0xFFF4F4F4)
val UmbrellaTextMuted = Color(0xFF8E939E)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private var tts: TextToSpeech? = null
    private var introPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        schedulePeriodicScan()

        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                tts?.setPitch(0.75f)
                tts?.setSpeechRate(0.85f)
            }
        }

        setContent {
            val darkColors = darkColorScheme(
                primary = UmbrellaRed,
                onPrimary = Color.White,
                background = UmbrellaBlack,
                onBackground = UmbrellaWhite,
                surface = UmbrellaPanel,
                onSurface = UmbrellaWhite,
                secondary = UmbrellaRedGlow,
                outline = UmbrellaPanelBorder
            )

            MaterialTheme(colorScheme = darkColors) {
                Surface(Modifier.fillMaxSize(), color = UmbrellaBlack) {
                    var showSplash by remember { mutableStateOf(true) }

                    LaunchedEffect(Unit) {
                        try {
                            introPlayer = MediaPlayer.create(this@MainActivity, R.raw.umbrella_intro)
                            introPlayer?.isLooping = false
                            introPlayer?.start()
                        } catch (_: Exception) { }

                        delay(5000)
                        tts?.speak("Welcome to Umbrella Corporation. Our business is life itself.", TextToSpeech.QUEUE_FLUSH, null, "welcome")

                        delay(2500)
                        showSplash = false
                        introPlayer?.let { player -> if (player.isPlaying) player.pause(); player.seekTo(0) }
                    }

                    Box(Modifier.fillMaxSize()) {
                        RadarScreen(
                            repo = ApiRepository(applicationContext),
                            onScan = ::runScan,
                            openWebsite = ::openWebsite,
                            onReplayBoot = {
                                showSplash = true
                            }
                        )

                        AnimatedVisibility(
                            visible = showSplash,
                            enter = fadeIn(tween(250)),
                            exit = fadeOut(tween(650))
                        ) {
                            UmbrellaSplash(
                                onSkip = {
                                    showSplash = false
                                    introPlayer?.let { player -> if (player.isPlaying) player.pause(); player.seekTo(0) }
                                    tts?.stop()
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        introPlayer?.run { if (isPlaying) stop(); release() }
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun openWebsite(url: String) {
        try {
            val uri = Uri.parse(url.trim())
            if (uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) {
                Toast.makeText(this, "Nieprawidłowy adres strony", Toast.LENGTH_SHORT).show()
                return
            }

            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage("com.android.chrome")
                })
                return
            } catch (_: Exception) { }

            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            } catch (_: Exception) {
                Toast.makeText(this, "Zainstaluj lub włącz przeglądarkę", Toast.LENGTH_LONG).show()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Nie udało się otworzyć strony", Toast.LENGTH_LONG).show()
        }
    }

    private fun schedulePeriodicScan() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val periodic = PeriodicWorkRequestBuilder<ScanWorker>(15, TimeUnit.MINUTES).setConstraints(constraints).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("free-api-radar-periodic", ExistingPeriodicWorkPolicy.KEEP, periodic)
        WorkManager.getInstance(this).enqueue(OneTimeWorkRequestBuilder<ScanWorker>().setConstraints(constraints).build())
    }

    private fun runScan() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        WorkManager.getInstance(this).enqueue(OneTimeWorkRequestBuilder<ScanWorker>().setConstraints(constraints).build())
    }
}

/**
 * 4-Phase Cinematic Startup Animation matching Section 2 of reference UI sheet
 */
@Composable
private fun UmbrellaSplash(onSkip: () -> Unit) {
    var stage by remember { mutableStateOf(1) }
    val startupMessage = "With our corporation you can feel safe and secure. Your life is our business."
    var typedMessage by remember { mutableStateOf("") }

    val infiniteTransition = rememberInfiniteTransition(label = "wireframe")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(7000, easing = LinearEasing)),
        label = "rot"
    )

    LaunchedEffect(Unit) {
        typedMessage = ""
        for (index in startupMessage.indices) {
            typedMessage = startupMessage.substring(0, index + 1)
            delay(28)
        }
    }

    LaunchedEffect(Unit) {
        delay(1500)
        stage = 2
        delay(1800)
        stage = 3
        delay(2000)
        stage = 4
    }

    Box(Modifier.fillMaxSize().background(UmbrellaBlack)) {
        if (stage >= 3) {
            Image(
                painter = painterResource(R.drawable.umbrella_splash),
                contentDescription = "Umbrella Corporation headquarters",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().alpha(if (stage == 4) 0.85f else 0.35f)
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = if (stage == 4) 0.35f else 0.7f)))
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 40.dp, start = 16.dp, end = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("> UMBRELLA BOOT SEQUENCE", color = UmbrellaRed, fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Button(
                onClick = onSkip,
                colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed.copy(alpha = 0.85f)),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("SKIP [ESC]", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }

        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            when (stage) {
                1 -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        CircularProgressIndicator(color = UmbrellaRed, strokeWidth = 3.dp, modifier = Modifier.size(54.dp))
                        Text("INITIALIZING...", color = UmbrellaRedGlow, fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text(typedMessage + "▌", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 32.dp))
                    }
                }
                2 -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Image(
                            painter = painterResource(R.drawable.umbrella_icon),
                            contentDescription = "Logo formation",
                            modifier = Modifier.size(110.dp).rotate(rotation)
                        )
                        Text("FORMING NEURAL LOGO MESH...", color = UmbrellaRedGlow, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                3 -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(24.dp)) {
                        Image(
                            painter = painterResource(R.drawable.umbrella_icon),
                            contentDescription = "Logo",
                            modifier = Modifier.size(96.dp)
                        )
                        Text("WELCOME TO\nUMBRELLA CORPORATION", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, letterSpacing = 1.5.sp)
                        Text("OUR BUSINESS IS LIFE ITSELF", color = UmbrellaRedGlow, fontFamily = FontFamily.Monospace, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    }
                }
                4 -> {
                    Column(
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 50.dp, start = 20.dp, end = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("WELCOME TO UMBRELLA CORPORATION", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                        Text("OUR BUSINESS IS LIFE ITSELF", color = UmbrellaRedGlow, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = onSkip,
                            colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth(0.85f).height(46.dp)
                        ) {
                            Text("ENTER CONSOLE", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        Text(
            "SECURE CONNECTION // PROTOCOL ACTIVE",
            color = Color(0xFF6B7280),
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp)
        )
    }
}

/**
 * Main Radar Console Screen
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RadarScreen(
    repo: ApiRepository,
    onScan: () -> Unit,
    openWebsite: (String) -> Unit,
    onReplayBoot: () -> Unit
) {
    val apis by repo.observe().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var keyFilter by remember { mutableStateOf("All") }
    var activeBottomTab by remember { mutableStateOf("home") }

    var customSources by remember { mutableStateOf(repo.customSources()) }
    var savedAddresses by remember { mutableStateOf(repo.savedAddresses()) }
    var hiddenResultIds by remember { mutableStateOf(repo.hiddenResultIds()) }

    var showDrawer by remember { mutableStateOf(false) }
    var showSources by remember { mutableStateOf(false) }
    var showSavedAddresses by remember { mutableStateOf(false) }
    var sourceInput by remember { mutableStateOf("") }

    var selectedEntryForDetails by remember { mutableStateOf<ApiEntry?>(null) }
    var pendingRemoval by remember { mutableStateOf<ApiEntry?>(null) }

    var is18PlusVerified by remember { mutableStateOf(false) }
    var show18PlusGate by remember { mutableStateOf(false) }

    val categories = listOf(
        "All",
        "AI & Machine Learning",
        "Text & Language",
        "Image & Vision",
        "Audio & Speech",
        "Image to Video & Motion",
        "Developer Tools",
        "18+ Classified"
    )

    val visible = apis.filter { entry ->
        entry.id !in hiddenResultIds &&
        (if (selectedCategory == "All") {
            entry.category != "18+ Classified" || is18PlusVerified
        } else {
            entry.category == selectedCategory
        }) &&
        (keyFilter == "All" || (keyFilter == "No key" && !entry.needsKey) || (keyFilter == "Key needed" && entry.needsKey)) &&
        (query.isBlank() || "${entry.name} ${entry.description} ${entry.category}".contains(query, true))
    }

    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.umbrella_interior_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().alpha(0.24f)
        )

        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                Column(Modifier.background(UmbrellaBlack.copy(alpha = 0.88f)).statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            IconButton(onClick = { showDrawer = true }, modifier = Modifier.size(36.dp)) {
                                Icon(Icons.Default.Menu, contentDescription = "Menu", tint = UmbrellaRedGlow)
                            }
                            Image(painterResource(R.drawable.umbrella_icon), contentDescription = "Umbrella Logo", modifier = Modifier.size(36.dp))
                            Column {
                                Text("Free API Radar", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("UMBRELLA CORPORATION", color = UmbrellaRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            }
                        }

                        Button(
                            onClick = {
                                customSources = repo.customSources()
                                showSources = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = UmbrellaPanel),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.border(1.dp, UmbrellaPanelBorder, RoundedCornerShape(6.dp))
                        ) {
                            Text("SOURCES", fontSize = 10.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                        }
                    }

                    if (selectedCategory == "18+ Classified") {
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().background(Color(0xFF3F0B11)).padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("RESTRICTED 18+ CLASSIFIED SPACE ACTIVE", color = UmbrellaRedGlow, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { selectedCategory = "All" }, contentPadding = PaddingValues(0.dp)) {
                                Text("EXIT SPACE", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            },
            bottomBar = {
                NavigationBar(
                    containerColor = UmbrellaBlack.copy(alpha = 0.95f),
                    tonalElevation = 8.dp,
                    modifier = Modifier.border(1.dp, UmbrellaPanelBorder, RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                ) {
                    NavigationBarItem(
                        selected = activeBottomTab == "home",
                        onClick = { activeBottomTab = "home"; selectedCategory = "All" },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Home", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = UmbrellaRed, selectedTextColor = UmbrellaRed, indicatorColor = Color.Transparent)
                    )
                    NavigationBarItem(
                        selected = activeBottomTab == "favorites",
                        onClick = {
                            activeBottomTab = "favorites"
                            savedAddresses = repo.savedAddresses()
                            showSavedAddresses = true
                        },
                        icon = { Icon(Icons.Default.Star, contentDescription = "Favorites") },
                        label = { Text("Favorites", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = UmbrellaRed, selectedTextColor = UmbrellaRed, indicatorColor = Color.Transparent)
                    )
                    NavigationBarItem(
                        selected = activeBottomTab == "sources",
                        onClick = {
                            activeBottomTab = "sources"
                            customSources = repo.customSources()
                            showSources = true
                        },
                        icon = { Icon(Icons.Default.Share, contentDescription = "Sources") },
                        label = { Text("Sources", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = UmbrellaRed, selectedTextColor = UmbrellaRed, indicatorColor = Color.Transparent)
                    )
                    NavigationBarItem(
                        selected = activeBottomTab == "settings",
                        onClick = {
                            activeBottomTab = "settings"
                            showDrawer = true
                        },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("Settings", fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = UmbrellaRed, selectedTextColor = UmbrellaRed, indicatorColor = Color.Transparent)
                    )
                }
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(paddingValues).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Spacer(Modifier.height(6.dp))

                    Box(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(UmbrellaPanel).border(1.dp, UmbrellaPanelBorder, RoundedCornerShape(10.dp)).padding(horizontal = 14.dp, vertical = 12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Search, contentDescription = null, tint = UmbrellaTextMuted, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(10.dp))
                            BasicTextField(
                                value = query,
                                onValueChange = { query = it },
                                modifier = Modifier.weight(1f),
                                textStyle = MaterialTheme.typography.bodyMedium.copy(color = UmbrellaWhite),
                                decorationBox = { innerTextField ->
                                    if (query.isEmpty()) {
                                        Text("Search free APIs, vision, video, models...", color = UmbrellaTextMuted, fontSize = 13.sp)
                                    }
                                    innerTextField()
                                }
                            )
                            if (query.isNotEmpty()) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = UmbrellaTextMuted, modifier = Modifier.size(18.dp).clickable { query = "" })
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("All", "No key", "Key needed").forEach { option ->
                                FilterChip(
                                    selected = keyFilter == option,
                                    onClick = { keyFilter = option },
                                    label = { Text(option, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = UmbrellaRed,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        Button(
                            onClick = onScan,
                            colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("SCAN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                item {
                    Text(
                        "CATEGORIES // CLASSIFIED INDEX",
                        color = UmbrellaRed,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    Spacer(Modifier.height(6.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        categories.chunked(2).forEach { pair ->
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                pair.forEach { cat ->
                                    val isSelected = selectedCategory == cat
                                    val is18 = cat == "18+ Classified"

                                    Card(
                                        modifier = Modifier.weight(1f).clickable {
                                            if (is18 && !is18PlusVerified) {
                                                show18PlusGate = true
                                            } else {
                                                selectedCategory = cat
                                            }
                                        },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) {
                                                if (is18) Color(0xFF6B1119) else UmbrellaRed
                                            } else {
                                                if (is18) Color(0xFF1E1012) else UmbrellaPanel
                                            }
                                        ),
                                        shape = RoundedCornerShape(8.dp),
                                        border = if (is18) BorderStroke(1.dp, Color(0xFF991B1B)) else BorderStroke(1.dp, UmbrellaPanelBorder)
                                    ) {
                                        Column(Modifier.padding(10.dp)) {
                                            Text(
                                                cat,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (is18 && !isSelected) UmbrellaRedGlow else Color.White
                                            )
                                            Text(
                                                when (cat) {
                                                    "Image to Video & Motion" -> "Runway, Luma, Kling, SVD"
                                                    "18+ Classified" -> "Restricted Adult Models"
                                                    "AI & Machine Learning" -> "LLMs, Neural Networks"
                                                    "Text & Language" -> "Translation, NLP"
                                                    "Image & Vision" -> "Generation, OCR"
                                                    "Audio & Speech" -> "TTS, Voice Tools"
                                                    "Developer Tools" -> "Utilities, Mock Data"
                                                    else -> "All Verified APIs"
                                                },
                                                fontSize = 9.sp,
                                                color = if (isSelected) Color(0xFFE5E7EB) else UmbrellaTextMuted,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                                if (pair.size == 1) {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("RESULTS (${visible.size})", color = UmbrellaWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("WORKMANAGER 15M INTERVAL", color = UmbrellaTextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                }

                if (visible.isEmpty()) {
                    item {
                        Box(Modifier.fillMaxWidth().padding(vertical = 32.dp), contentAlignment = Alignment.Center) {
                            Text("No API entries found matching criteria. Tap SCAN to probe sources.", color = UmbrellaTextMuted, fontSize = 12.sp, textAlign = TextAlign.Center)
                        }
                    }
                }

                items(visible, key = { it.id }) { entry ->
                    ApiCard(
                        entry = entry,
                        isSaved = entry.docsUrl in savedAddresses,
                        onOpenDetails = { selectedEntryForDetails = entry },
                        onSaveUrl = {
                            repo.saveAddress(entry.docsUrl)
                            savedAddresses = repo.savedAddresses()
                        },
                        onRemoveResult = { pendingRemoval = entry },
                        onCheck = {
                            scope.launch {
                                val status = repo.checkWebsite(entry)
                                repo.saveStatus(entry.id, status)
                            }
                        },
                        onOpenWebsite = { openWebsite(entry.docsUrl) }
                    )
                }

                item {
                    Spacer(Modifier.height(16.dp))
                }
            }
        }

        if (showDrawer) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.75f)).clickable { showDrawer = false }
            ) {
                Column(
                    modifier = Modifier.fillMaxHeight().width(290.dp).background(Color(0xFF0F1116)).border(1.dp, UmbrellaRed.copy(alpha = 0.4f)).padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Image(painterResource(R.drawable.umbrella_icon), contentDescription = null, modifier = Modifier.size(42.dp))
                        Column {
                            Text("Free API Radar", color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp)
                            Text("UMBRELLA CORPORATION", color = UmbrellaRed, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        }
                    }

                    Spacer(Modifier.height(24.dp))
                    Divider(color = UmbrellaPanelBorder)
                    Spacer(Modifier.height(16.dp))

                    val drawerItems = listOf(
                        "Home" to Icons.Default.Home,
                        "Search" to Icons.Default.Search,
                        "Favorites" to Icons.Default.Star,
                        "History & Sources" to Icons.Default.Share,
                        "Settings" to Icons.Default.Settings,
                        "About Umbrella" to Icons.Default.Info,
                        "Exit / Replay Boot" to Icons.Default.ExitToApp
                    )

                    drawerItems.forEach { (label, icon) ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable {
                                showDrawer = false
                                when (label) {
                                    "Home" -> { selectedCategory = "All"; activeBottomTab = "home" }
                                    "Search" -> { query = "" }
                                    "Favorites" -> { savedAddresses = repo.savedAddresses(); showSavedAddresses = true }
                                    "History & Sources" -> { customSources = repo.customSources(); showSources = true }
                                    "About Umbrella" -> { }
                                    "Exit / Replay Boot" -> { onReplayBoot() }
                                }
                            }.padding(vertical = 12.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(icon, contentDescription = null, tint = UmbrellaRedGlow, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(14.dp))
                            Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Spacer(Modifier.weight(1f))

                    Column(
                        modifier = Modifier.fillMaxWidth().background(Color(0xFF090B0E)).padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = painterResource(R.drawable.umbrella_icon),
                            contentDescription = null,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(Modifier.height(6.dp))
                        Text("OUR BUSINESS IS LIFE ITSELF", color = UmbrellaRedGlow, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Text("GLOBAL RADAR // SECURE", color = UmbrellaTextMuted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        if (selectedEntryForDetails != null) {
            val entry = selectedEntryForDetails!!
            AlertDialog(
                onDismissRequest = { selectedEntryForDetails = null },
                confirmButton = {
                    Button(
                        onClick = { openWebsite(entry.docsUrl) },
                        colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Open in Browser", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedEntryForDetails = null }) {
                        Text("CLOSE", color = UmbrellaTextMuted)
                    }
                },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Image(painterResource(R.drawable.umbrella_icon), contentDescription = null, modifier = Modifier.size(32.dp))
                        Column {
                            Text(entry.name, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(entry.category, fontSize = 11.sp, color = UmbrellaRedGlow, fontFamily = FontFamily.Monospace)
                        }
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Text(entry.description, fontSize = 12.sp, color = Color.White)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.background(Color(0xFF0B0D11)).padding(8.dp).weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Rate Limit", fontSize = 9.sp, color = UmbrellaTextMuted)
                                Text("Free Tier", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Spacer(Modifier.width(6.dp))
                            Column(Modifier.background(Color(0xFF0B0D11)).padding(8.dp).weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Auth", fontSize = 9.sp, color = UmbrellaTextMuted)
                                Text(entry.auth, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                            }
                            Spacer(Modifier.width(6.dp))
                            Column(Modifier.background(Color(0xFF0B0D11)).padding(8.dp).weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Docs", fontSize = 9.sp, color = UmbrellaTextMuted)
                                Text("HTTPS View", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34D399))
                            }
                        }

                        Text("Response Example", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = UmbrellaRed)
                        Box(
                            Modifier.fillMaxWidth().background(Color(0xFF090A0D)).border(1.dp, UmbrellaPanelBorder).padding(10.dp)
                        ) {
                            Text(
                                "{\n  \"status\": \"200 OK\",\n  \"service\": \"${entry.name}\",\n  \"category\": \"${entry.category}\",\n  \"auth_required\": ${entry.needsKey},\n  \"verified\": true\n}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = Color(0xFF93C5FD)
                            )
                        }
                    }
                },
                containerColor = UmbrellaPanel,
                shape = RoundedCornerShape(14.dp)
            )
        }

        if (show18PlusGate) {
            AlertDialog(
                onDismissRequest = { show18PlusGate = false },
                title = {
                    Text("LEVEL 4 CLASSIFIED // 18+ VERIFICATION", color = UmbrellaRed, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                },
                text = {
                    Text("This separate space contains adult APIs, uncensored generation models, and NSFW endpoints. Confirm you are at least 18 years of age to proceed.", fontSize = 12.sp, color = Color.White)
                },
                confirmButton = {
                    Button(
                        onClick = {
                            is18PlusVerified = true
                            show18PlusGate = false
                            selectedCategory = "18+ Classified"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed)
                    ) {
                        Text("I AM 18+ PROCEED", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { show18PlusGate = false }) {
                        Text("CANCEL", color = UmbrellaTextMuted)
                    }
                },
                containerColor = Color(0xFF190C0E),
                shape = RoundedCornerShape(12.dp)
            )
        }

        if (pendingRemoval != null) {
            val entryToRemove = pendingRemoval!!
            AlertDialog(
                onDismissRequest = { pendingRemoval = null },
                title = { Text("REMOVE RESULT?", color = UmbrellaRed, fontWeight = FontWeight.Bold) },
                text = { Text("Remove ${entryToRemove.name} from your results? It will stay hidden after future scans on this device.", color = Color.White, fontSize = 12.sp) },
                confirmButton = {
                    Button(
                        onClick = {
                            repo.hideResult(entryToRemove.id)
                            hiddenResultIds = repo.hiddenResultIds()
                            pendingRemoval = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed)
                    ) {
                        Text("REMOVE")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingRemoval = null }) {
                        Text("CANCEL", color = UmbrellaTextMuted)
                    }
                },
                containerColor = UmbrellaPanel
            )
        }

        if (showSavedAddresses) {
            AlertDialog(
                onDismissRequest = { showSavedAddresses = false },
                title = { Text("SAVED URLS // BOOKMARKS", color = UmbrellaRed, fontWeight = FontWeight.Bold, fontSize = 15.sp) },
                text = {
                    if (savedAddresses.isEmpty()) {
                        Text("No saved website addresses yet. Use SAVE URL on any catalog card.", color = UmbrellaTextMuted, fontSize = 12.sp)
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 380.dp)) {
                            items(savedAddresses, key = { it }) { url ->
                                Column(
                                    modifier = Modifier.fillMaxWidth().background(Color(0xFF0F1116)).padding(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(url, fontSize = 11.sp, color = UmbrellaWhite, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { openWebsite(url) },
                                            colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text("OPEN", fontSize = 10.sp)
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                repo.removeSavedAddress(url)
                                                savedAddresses = repo.savedAddresses()
                                            },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text("DELETE", fontSize = 10.sp, color = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSavedAddresses = false }) { Text("DONE", color = UmbrellaRed) }
                },
                containerColor = UmbrellaPanel
            )
        }

        if (showSources) {
            AlertDialog(
                onDismissRequest = { showSources = false },
                title = { Text("CATALOG SOURCES", color = UmbrellaRed, fontWeight = FontWeight.Bold, fontSize = 15.sp) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Observed repositories include public-apis, awesome-free-ai-apis, free-llm-api-hub, and curated video/18+ feeds.", fontSize = 11.sp, color = Color.White)
                        OutlinedTextField(
                            value = sourceInput,
                            onValueChange = { sourceInput = it },
                            label = { Text("Custom HTTPS Markdown Source URL") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                if (repo.addCustomSource(sourceInput)) {
                                    sourceInput = ""
                                    customSources = repo.customSources()
                                    onScan()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("ADD SOURCE")
                        }

                        if (customSources.isNotEmpty()) {
                            Text("CUSTOM SOURCES:", color = UmbrellaRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            customSources.forEach { source ->
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                    Text(source, modifier = Modifier.weight(1f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.White)
                                    TextButton(onClick = {
                                        repo.removeCustomSource(source)
                                        customSources = repo.customSources()
                                    }) {
                                        Text("DEL", color = UmbrellaRed, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSources = false }) { Text("DONE", color = UmbrellaRed) }
                },
                containerColor = UmbrellaPanel
            )
        }
    }
}

/**
 * Result Card Composable
 */
@Composable
private fun ApiCard(
    entry: ApiEntry,
    isSaved: Boolean,
    onOpenDetails: () -> Unit,
    onSaveUrl: () -> Unit,
    onRemoveResult: () -> Unit,
    onCheck: () -> Unit,
    onOpenWebsite: () -> Unit
) {
    val is18 = entry.category == "18+ Classified"
    val isVideo = entry.category == "Image to Video & Motion"

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (is18) Color(0xFF1C0D10) else UmbrellaPanel
        ),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, if (is18) Color(0xFF7F1D1D) else UmbrellaPanelBorder)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(entry.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = UmbrellaWhite)
                if (is18) {
                    Text("18+", color = UmbrellaRedGlow, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                } else if (isVideo) {
                    Text("VIDEO", color = Color(0xFFA855F7), fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }

            Text(entry.description, fontSize = 12.sp, color = Color(0xFFD1D5DB), maxLines = 2, overflow = TextOverflow.Ellipsis)

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(entry.category, fontSize = 10.sp, color = UmbrellaRedGlow, fontFamily = FontFamily.Monospace)
                Text("·", color = UmbrellaTextMuted, fontSize = 10.sp)
                Text("Access: ${entry.auth}", fontSize = 10.sp, color = UmbrellaTextMuted)
                Text("·", color = UmbrellaTextMuted, fontSize = 10.sp)
                Text(entry.https, fontSize = 10.sp, color = Color(0xFF34D399))
            }

            Text("Status: ${entry.siteStatus}", fontSize = 10.sp, color = UmbrellaTextMuted)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = onOpenWebsite,
                    colors = ButtonDefaults.buttonColors(containerColor = UmbrellaRed),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.weight(1.2f)
                ) {
                    Text("OPEN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onOpenDetails,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF232630)),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("DETAILS", fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = onCheck,
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    modifier = Modifier.weight(0.9f)
                ) {
                    Text("CHECK", fontSize = 10.sp, color = Color.White)
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = onSaveUrl,
                    enabled = !isSaved,
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (isSaved) "SAVED" else "SAVE URL", fontSize = 10.sp, color = if (isSaved) Color.Gray else Color.White)
                }

                OutlinedButton(
                    onClick = onRemoveResult,
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("REMOVE", fontSize = 10.sp, color = Color(0xFFF87171))
                }
            }
        }
    }
}
