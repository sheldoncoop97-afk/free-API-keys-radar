# Changelog — Umbrella Corp

## Umbra Watch 1.3 — packaged project
- Consolidated the Android source into a standalone Android Studio project.
- Set the launcher/app label to **Umbrella Corp**.
- Updated the main in-app heading to **UMBRELLA CORP**.
- Fixed the website button callback so catalog entries pass their documentation URL to the activity.
- Updated link opening to try Chrome first and then the default/available browser.
- Added a standalone GitHub Actions workflow that builds and uploads `Umbrella-Corp-debug-apk`.
- Preserved the existing Umbrella logo, startup animation/audio, catalog scanning, MY SOURCES, notifications and 15-minute WorkManager configuration.


## Result management checkpoint
- Added local persistent URL bookmarks from catalog result cards.
- Added a Saved URLs dialog with Open and Delete actions.
- Added confirmed Remove Result action; hidden result IDs persist locally and stay filtered after later catalog scans.
- Kept catalog scanning, categories, key filters, website checks, custom sources, splash artwork, and startup audio.
- Build status: not verified in this environment; the ZIP has not been claimed as a successfully compiled APK.


## Visual refresh + category navigation checkpoint
- Increased visibility of the in-app laboratory background while retaining a dark readability overlay.
- Added a dedicated Categories page with counts and navigation to filtered results.
- Added an 18+ / Porn AI category with an age-confirmation dialog and adult/NSFW metadata classification. This category is populated only when matching entries are found in public catalogs or added public HTTPS Markdown sources.
- Kept the existing launcher icon assets unchanged, as requested.
- Preserved saved URLs, persistent result removal, custom sources, catalog scan, site checks, startup artwork and startup MP3.
- Verification: archive integrity and project-file checks performed. Android APK compilation/runtime remain unverified in this environment because Android SDK/Gradle are not installed here.
